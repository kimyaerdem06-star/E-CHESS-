const C = 'echess-v19';
// Çevrimdışı açılış için şart olan çekirdek dosyalar: biri bile inmezse kurulum başarısız olur (yarım önbellek kalmasın)
const CORE = ['./', './index.html', './app.js', './review.html', './review.js', './manifest.json'];
// Tek tek eklenir: biri eksik olsa da kurulum bozulmaz
const ASSETS = ['./icon-192.png', './icon-512.png', './icon-maskable.png', './pieces/wK.svg', './pieces/bK.svg', './pieces/wQ.svg', './pieces/bQ.svg', './pieces/wR.svg', './pieces/bR.svg', './pieces/wB.svg', './pieces/bB.svg', './pieces/wN.svg', './pieces/bN.svg', './pieces/wP.svg', './pieces/bP.svg'];
// Stockfish 19 motoru (eksikse kurulum bozulmasın diye ayrı ve hata toleranslı)
const ENGINE_FILES = ['./stockfish-19-lite-single.js', './stockfish-19-lite-single.wasm'];
// app.js'in dışarıdan yüklediği kütüphaneler: çevrimdışı çalışsın diye önbelleğe alınır
const CDN = 'https://cdn.jsdelivr.net';
const CDN_FILES = [
  CDN + '/npm/chess.js@1.0.0/+esm',
  CDN + '/npm/@supabase/supabase-js@2.45.0/+esm'
];
// İnternet "var ama çalışmıyor" ise (captive portal, zayıf çekim) bu süreden sonra önbellekten aç
const NET_TIMEOUT = 4000;

const keep = (req, r) => {
  if (r && r.status === 200) { const x = r.clone(); caches.open(C).then(c => c.put(req, x)).catch(() => {}); }
  return r;
};

// jsDelivr +esm dosyaları başka modülleri de import eder (örn. supabase-js alt paketleri).
// Onları da önceden indirmezsek ilk açılışta internet kesilirse modül yüklenemez.
async function cacheEsm(c, url, seen) {
  if (seen.has(url) || seen.size > 60) return;
  seen.add(url);
  try {
    let r = await c.match(url);
    if (!r) {
      r = await fetch(url);
      if (!r.ok) return;
      await c.put(url, r.clone());
    }
    const txt = await r.clone().text();
    const re = /(?:from|import)\s*["'](\/npm\/[^"']+)["']/g, subs = [];
    let m;
    while ((m = re.exec(txt))) subs.push(CDN + m[1]);
    await Promise.all(subs.map(s => cacheEsm(c, s, seen)));
  } catch {}
}

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(C);
    await c.addAll(CORE);
    await Promise.all(ASSETS.map(u => c.add(u).catch(() => {})));
    const seen = new Set();
    await Promise.all(CDN_FILES.map(u => cacheEsm(c, u, seen)));
    await Promise.all(ENGINE_FILES.map(u => fetch(u, {cache: 'reload'}).then(r => r.ok && c.put(u, r)).catch(() => {})));
  })());
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))).then(() => self.clients.claim()));
});

// Önce ağ (güncel içerik), ağ yoksa / yavaşsa / hata veriyorsa önbellek
async function netFirst(e, req) {
  const net = fetch(req).then(r => (r.ok ? keep(req, r) : r));
  e.waitUntil(net.catch(() => {})); // yavaş ağda önbellek yanıtı verilse bile güncelleme arkada tamamlansın
  const quick = new Promise(res => setTimeout(() => res(null), NET_TIMEOUT));
  const r = await Promise.race([net.catch(() => null), quick]);
  if (r && r.ok) return r;
  const hit = await caches.match(req, {ignoreSearch: true});
  if (hit) return hit;
  if (req.mode === 'navigate' && new URL(req.url).pathname.endsWith('/review.html')) {
    const review = await caches.match('./review.html');
    if (review) return review;
  }
  if (req.mode === 'navigate') { const idx = await caches.match('./index.html'); if (idx) return idx; }
  if (r) return r;
  return net.catch(() => Response.error());
}

self.addEventListener('fetch', e => {
  const req = e.request, u = new URL(req.url);
  if (req.method !== 'GET' || req.headers.has('range')) return;
  if (u.origin === CDN) { // sürümlü dosyalar değişmez: önce önbellek
    e.respondWith(caches.match(req, {ignoreVary: true}).then(hit => hit || fetch(req).then(r => keep(req, r))));
    return;
  }
  if (u.origin !== location.origin) return; // Supabase vb. asla önbelleğe alınmaz
  if (/\/stockfish-19-lite-single\.(js|wasm)$/.test(u.pathname)) { // motor dosyaları: önce önbellek; yoksa indirip sakla
    e.respondWith(caches.match(req, {ignoreSearch: true}).then(h => h || fetch(req).then(r => keep(req, r))));
    return;
  }
  e.respondWith(netFirst(e, req));
});
