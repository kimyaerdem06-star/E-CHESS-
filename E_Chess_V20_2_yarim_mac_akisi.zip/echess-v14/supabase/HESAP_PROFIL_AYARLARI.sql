-- v8 profil alanları; canlı Supabase projesinde de uygulanmıştır.
alter table public.profiles
  add column if not exists display_name text,
  add column if not exists bio text,
  add column if not exists avatar_url text;
update public.profiles set display_name = username where display_name is null;
