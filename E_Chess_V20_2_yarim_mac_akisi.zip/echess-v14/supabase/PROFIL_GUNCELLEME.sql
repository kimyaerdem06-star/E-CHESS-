-- E Chess: Kullanıcının yalnızca kendi profilindeki kullanıcı adını değiştirebilmesi
-- profiles.username üzerinde mevcut benzersiz kısıt ve 3-16 karakter kontrolü korunur.
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
on public.profiles
for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);
