-- Kullanıcı adı değişince eski Supabase Auth e-postasıyla giriş zorunluluğunu kaldırır.
create table if not exists public.username_login_aliases (
  username text primary key,
  login_email text not null unique
);
alter table public.username_login_aliases enable row level security;
drop policy if exists "username_login_aliases_read" on public.username_login_aliases;
create policy "username_login_aliases_read" on public.username_login_aliases
for select to anon, authenticated using (true);
grant select on public.username_login_aliases to anon, authenticated;

create or replace function public.sync_username_login_alias()
returns trigger language plpgsql security definer set search_path = public, auth as $$
declare v_email text;
begin
  select email into v_email from auth.users where id = new.id;
  if v_email is not null then
    if tg_op = 'UPDATE' and old.username is distinct from new.username then
      delete from public.username_login_aliases where username = lower(old.username);
    end if;
    insert into public.username_login_aliases(username, login_email)
    values (lower(new.username), v_email)
    on conflict (username) do update set login_email = excluded.login_email;
  end if;
  return new;
end; $$;
revoke all on function public.sync_username_login_alias() from public, anon, authenticated;
drop trigger if exists profiles_sync_username_login_alias on public.profiles;
create trigger profiles_sync_username_login_alias
after insert or update of username on public.profiles
for each row execute function public.sync_username_login_alias();

insert into public.username_login_aliases(username, login_email)
select lower(p.username), u.email from public.profiles p
join auth.users u on u.id = p.id
where p.username is not null and u.email is not null
on conflict (username) do update set login_email = excluded.login_email;
