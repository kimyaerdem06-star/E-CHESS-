-- E Chess: rakip bağlantı durumunu ve kopma süresini güvenli izlemek için heartbeat tablosu.
create table if not exists public.game_presence (
  game_id uuid not null references public.chess_games(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  seen_at timestamptz not null default now(),
  primary key (game_id, user_id)
);
create index if not exists game_presence_seen_at_idx on public.game_presence (game_id, seen_at desc);
alter table public.game_presence enable row level security;
drop policy if exists game_presence_select_own on public.game_presence;
drop policy if exists game_presence_insert_own on public.game_presence;
drop policy if exists game_presence_update_own on public.game_presence;
create policy game_presence_select_own on public.game_presence for select to authenticated
  using (user_id = (select auth.uid()));
create policy game_presence_insert_own on public.game_presence for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (
    select 1 from public.chess_games g where g.id = game_id
    and ((select auth.uid()) = g.white_id or (select auth.uid()) = g.black_id)
  ));
create policy game_presence_update_own on public.game_presence for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()) and exists (
    select 1 from public.chess_games g where g.id = game_id
    and ((select auth.uid()) = g.white_id or (select auth.uid()) = g.black_id)
  ));
grant select, insert, update on public.game_presence to authenticated;
