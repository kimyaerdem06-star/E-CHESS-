import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed." }, 405);
  try {
    const url = Deno.env.get("SUPABASE_URL"), anon = Deno.env.get("SUPABASE_ANON_KEY"), service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !anon || !service) return json({ ok: false, error: "Sunucu yapılandırması eksik." }, 500);
    const authorization = req.headers.get("Authorization") || "";
    const userClient = createClient(url, anon, { auth: { persistSession: false, autoRefreshToken: false }, global: { headers: { Authorization: authorization } } });
    const { data: authData, error: authError } = await userClient.auth.getUser();
    if (authError || !authData.user) return json({ ok: false, error: "Giriş gerekli." }, 401);
    const gid = String((await req.json()).gid || "");
    if (!gid) return json({ ok: false, error: "Maç kimliği eksik." }, 400);
    const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: game, error } = await admin.from("chess_games").select("*").eq("id", gid).maybeSingle();
    if (error || !game) return json({ ok: false, error: "Maç bulunamadı." }, 404);
    const userId = authData.user.id;
    if (userId !== game.white_id && userId !== game.black_id) return json({ ok: false, error: "Bu maçta oyuncu değilsin." }, 403);
    if (game.status !== "playing" || !game.black_id) return json({ ok: false, error: "Maç aktif değil." }, 409);
    const moves = Array.isArray(game.move_history) ? game.move_history : [];
    if (moves.length !== 1) return json({ ok: false, error: "İptal yalnızca ilk hamleden sonra kullanılabilir." }, 409);
    const currentTurn = String(game.fen || "").split(" ")[1], requesterColor = userId === game.white_id ? "w" : "b";
    if (currentTurn === requesterColor) return json({ ok: false, error: "İptal hakkı yalnızca ilk hamleyi yapan oyuncuda." }, 403);
    if (Date.now() - new Date(game.turn_ts).getTime() < 60000) return json({ ok: false, error: "Rakibin hamle yapması için 60 saniye beklenmeli." }, 409);
    const opponentId = currentTurn === "w" ? game.white_id : game.black_id;
    const { data: presence, error: presenceError } = await admin.from("game_presence").select("seen_at").eq("game_id", gid).eq("user_id", opponentId).maybeSingle();
    if (presenceError) return json({ ok: false, error: "Bağlantı durumu okunamadı." }, 500);
    if (!presence?.seen_at || Date.now() - new Date(presence.seen_at).getTime() < 60000) return json({ ok: false, error: "Rakip hâlâ çevrimiçi görünüyor veya bağlantı kaydı yok." }, 409);
    const { error: markError } = await admin.from("chess_games").update({ rated: false }).eq("id", gid).eq("status", "playing");
    if (markError) return json({ ok: false, error: "Maç iptal durumu kaydedilemedi." }, 500);
    const { error: finishError } = await admin.rpc("finish_game_server", { p_gid: gid, p_outcome: "d" });
    if (finishError) return json({ ok: false, error: "Maç iptal edilemedi." }, 500);
    const { data: finished } = await admin.from("chess_games").select("*").eq("id", gid).single();
    return json({ ok: true, game: finished, message: "Maç ilk hamlede iptal edildi; ELO ve istatistikler değişmedi." });
  } catch (error) { return json({ ok: false, error: "Sunucu hatası.", detail: String(error).slice(0, 180) }, 500); }
});
