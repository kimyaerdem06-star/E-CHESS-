import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const authHeader = req.headers.get("Authorization") || "";
  if (!authHeader.startsWith("Bearer ")) return Response.json({ error: "Oturum gerekli." }, { status: 401 });
  const url = Deno.env.get("SUPABASE_URL")!;
  const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) return Response.json({ error: "Oturum doğrulanamadı." }, { status: 401 });
  const admin = createClient(url, service);
  const { error: aliasError } = await admin.from("username_login_aliases").delete().eq("login_email", user.email ?? "");
  if (aliasError) return Response.json({ error: "Hesap giriş kaydı temizlenemedi." }, { status: 500 });
  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) return Response.json({ error: "Hesap silinemedi: " + error.message }, { status: 500 });
  return Response.json({ success: true });
});
