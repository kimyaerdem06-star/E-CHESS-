-- E Chess: bot ve aynı cihazda oynanan maçları kullanıcı geçmişinde sakla
create table if not exists public.practice_games (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  mode text not null check (mode in ('bot','local')),
  opponent_name text not null,
  tc integer not null default 0,
  white_name text not null,
  black_name text not null,
  result text not null check (result in ('w','b','d')),
  moves jsonb not null default '[]'::jsonb,
  pgn text not null,
  created_at timestamptz not null default now()
);

alter table public.practice_games enable row level security;

drop policy if exists practice_games_select_own on public.practice_games;
create policy practice_games_select_own on public.practice_games
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists practice_games_insert_own on public.practice_games;
create policy practice_games_insert_own on public.practice_games
  for insert to authenticated with check ((select auth.uid()) = user_id);

grant select, insert on public.practice_games to authenticated;
