// Önce yerel /vendor kopyası, yoksa CDN. İnternet yokken bot modu yerel dosyalarla açılır.
const imp = async (...urls) => { for (const u of urls) { try { return await import(u); } catch {} } return null; };
const CDN = 'https://cdn.jsdelivr.net/npm/';
const chessMod = await imp('/vendor/chess.js', CDN + 'chess.js@1.0.0/+esm');
if (!chessMod) { document.body.innerHTML = '<p style="padding:24px;font-family:sans-serif;color:#eee">Satranç kütüphanesi yüklenemedi. Bir kez internete bağlanıp sayfayı yenile (veya vendor-indir.sh çalıştır).</p>'; throw new Error('chess.js yok'); }
const {Chess} = chessMod;
const sbMod = await imp(CDN + '@supabase/supabase-js@2.45.0/+esm');

const SB_URL = 'https://aahxhwmiweksufzllspi.supabase.co';
const SB_KEY = 'sb_publishable_SKqDFVPHI_xgHZ9nx-XxiA_ub1Okdlj';
const ONLINE_OK = !!sbMod;
const nope = () => { throw new Error('offline'); };
const sb = sbMod ? sbMod.createClient(SB_URL, SB_KEY)
  : {auth: {getSession: async () => ({data: {session: null}}), onAuthStateChange() {}, signOut: async () => {}, signUp: nope, signInWithPassword: nope}, from: nope, rpc: nope, channel: nope, removeChannel: async () => {}};
const $ = s => document.querySelector(s);
function applyTheme(mode = localStorage.getItem('echess_theme') || 'system') {
  if (!['light','dark','system'].includes(mode)) mode='system';
  document.body.dataset.theme=mode;
  document.body.classList.toggle('light-theme',mode==='light');
  localStorage.setItem('echess_theme',mode);
  const meta=document.querySelector('meta[name="theme-color"]'); if(meta) meta.content=mode==='light'?'#f3f4f6':mode==='dark'?'#302e2b':'#302e2b';
}
applyTheme();
if (window.matchMedia) { const mq=window.matchMedia('(prefers-color-scheme: light)'); mq.addEventListener?.('change',()=>{if((localStorage.getItem('echess_theme')||'system')==='system') applyTheme('system');}); }
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SAVE = 'echess_gid';
const PRACTICE_SAVE = 'echess_practice_active_v1';
const practiceKey = m => `echess_practice_${m}_v1`;
const readPractice = m => { try { return JSON.parse(localStorage.getItem(practiceKey(m)) || (JSON.parse(localStorage.getItem(PRACTICE_SAVE)||'null')?.mode===m ? localStorage.getItem(PRACTICE_SAVE) : 'null')); } catch { return null; } };
let restoringPractice = false;
let onlineResumeRow = null;
const SFS = ['./stockfish-19-lite-single.js'];
const PC = '/pieces/';
const CATS = [['Başlangıç',[250,400,550,700]],['Orta',[850,1000,1100,1200]],['Gelişmiş',[1300,1400,1500,1600]],['İleri',[1700,1800,1900,2000]],['Uzman',[2100,2200,2300,2400]],['Usta',[2500,2600,2700,2800]],['Büyükusta',[2900,3000,3100,3200]]];

let user = null, prof = null, tc = 5;
let lview = 'w', view = 'home';
let soc = {fs: [], pr: {}, ch: []}, socSig = '', sch = null, chal = null, chalT = null, chalBusy = false;
let presenceTimer=null, opponentOnline=null;
let vi = null, g, mode, my = 'w', sel = null, tg = [], last = null, over = false, msg = '', botR = 0, gid = null, ch = null, started = false, sf = null, wt = null;
let ms = {w: 0, b: 0}, recv = 0, ending = false, tick = null, row0 = null;
let hint = null, hintBusy = false, anTok = 0, drag = null, dragEnd = 0, drawOff = null, drawTok = 0, dlgDraw = false, rmWait = false, rmFrom = null, joining = false, askCancel = () => {};
let pushing = 0, noEngine = false, pend = null, finTimer = null, ovDismissed = false, endRes = null, endWhy = '', eloBefore = null, eloNow = null, eloTc = 3, eloAsked = false;
let premove = null, practiceSaved = false, waitTimeout = null;
let boardDrawMode = false, boardMarks = [], boardMarkFrom = null, pendingBotResolve = null;
let evalEnabled = localStorage.getItem('echess_evalbar') === '1', evalTimer = null, evalSeq = 0;

// ===== Ses (dosyasız, WebAudio ile üretilir; internetsiz de çalışır) =====
let ac = null, capNow = false, muted = localStorage.getItem('echess_mute') === '1';
const unlock = () => { try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); } catch {} };
document.addEventListener('pointerdown', unlock);
function tone(f0, f1, dur, vol, type, at) {
  const t = ac.currentTime + (at || 0), o = ac.createOscillator(), gn = ac.createGain();
  o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
  gn.gain.setValueAtTime(vol, t); gn.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(gn).connect(ac.destination); o.start(t); o.stop(t + dur + 0.03);
}
function noise(dur, vol, freq, at, q) {
  const t = ac.currentTime + (at || 0), n = Math.max(1, Math.floor(ac.sampleRate * dur)), buf = ac.createBuffer(1, n, ac.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  const src = ac.createBufferSource(), f = ac.createBiquadFilter(), gn = ac.createGain();
  src.buffer = buf; f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q || 1; gn.gain.setValueAtTime(vol, t); gn.gain.exponentialRampToValueAtTime(0.001, t + dur);
  src.connect(f).connect(gn).connect(ac.destination); src.start(t);
}
// Üç ses: "tak" (normal), "ttak" (yeme), "tttâk" (şah, son vuruş uzayarak çınlar)
function wtap(vol, at, ring) {
  noise(0.025, 0.65 * vol, 1100, at, 6);
  tone(190, ring ? 175 : 150, ring ? 0.3 : 0.06, 0.3 * vol, 'sine', at);
  if (ring) tone(380, 350, 0.18, 0.1 * vol, 'sine', at);
}
function playMove(cap, chk) {
  if (muted || !ac) return;
  try {
    // T sayısı arttıkça ses yükselir: tak (kısık) < ttak (orta) < tttâk (en yüksek)
    if (chk) { wtap(0.55, 0); wtap(0.8, 0.05); wtap(1, 0.105, true); }
    else if (cap) { wtap(0.4, 0); wtap(0.6, 0.055); }
    else wtap(0.3, 0);
  } catch {}
}

function show(id) {
  view = id;
  for (const x of ['home','auth','game','wait','lb','fr','pw','history','player','settings']) $('#' + x).classList.toggle('hide', x !== id);
  const nav = $('#appnav');
  const navVisible = ['home','fr','lb','history','player','settings'].includes(id);
  nav.classList.toggle('hide', !navVisible);
  const active = id === 'fr' ? 'fr' : id === 'history' ? 'history' : id === 'settings' ? 'settings' : id === 'player' ? 'stats' : id === 'lb' ? 'stats' : 'home';
  nav.querySelectorAll('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === active));
  document.body.classList.toggle('has-bottom-nav', navVisible);
}
const seg = (cur, id) => [3,5,10].map(n => `<button class="${n === cur ? 'on' : ''}" data-a="${id}:${n}">${n} dk</button>`).join('');

// ===== Oturum =====
async function loadProf() {
  prof = null;
  if (user) {
    for (let i = 0; i < 4 && !prof; i++) {
      const {data} = await sb.from('profiles').select('*').eq('id', user.id).maybeSingle();
      prof = data;
      if (!prof) await new Promise(r => setTimeout(r, 600));
    }
  }
  try {
    if (prof) localStorage.setItem('echess_prof', JSON.stringify(prof));
    else if (user) { const c = JSON.parse(localStorage.getItem('echess_prof') || 'null'); if (c && c.id === user.id) prof = c; }
  } catch {}
  if (user && prof) { socialSub(); socialRefresh(true); } else if (!user) socialUnsub();
  if (mode) return; // oyun ekranındayken (token yenilenmesi vb.) menüye atma
  home();
  if (prof && new URLSearchParams(location.search).has('add')) { frShow(); return; }
  if (prof) resume();
  resumePractice();
}
async function resume() {
  const id = localStorage.getItem(SAVE);
  if (!id || gid) return;
  const {data} = await sb.from('chess_games').select('*').eq('id', id).maybeSingle();
  if (!data || data.status !== 'playing' || ![data.white_id, data.black_id].includes(user.id)) { localStorage.removeItem(SAVE); return; }
  onlineResumeRow = data;
  home();
}
sb.auth.getSession().then(({data}) => { user = data.session?.user || null; loadProf(); });
sb.auth.onAuthStateChange((_e, s) => { setTimeout(() => { user = s?.user || null; loadProf(); }, 0); });

function home() {
  const top = prof
    ? `<div class="card rw"><span class="profileline">${prof.avatar_url ? `<img class="avatar" src="${esc(prof.avatar_url)}" alt="">` : `<span class="avatar">${esc((prof.display_name||prof.username||'E').slice(0,1).toUpperCase())}</span>`}<span><b>${esc(prof.display_name || prof.username)}</b><br><small style="color:var(--mut)">@${esc(prof.username)} · ELO ${prof.elo}</small></span></span><button data-a="settings" aria-label="Profil ve ayarlar">⚙️</button></div>`
    : ''; // Giriş butonu yalnızca üst başlıkta gösterilir; tekrar eden büyük buton kaldırıldı.
  const nin = prof ? soc.fs.filter(f => f.status === 'pending' && f.addressee_id === user.id).length + soc.ch.filter(c => c.to_id === user.id).length : 0;
  const botPractice = readPractice('bot'), localPractice = readPractice('local');
  const practiceButton = (m, snap) => snap && Array.isArray(snap.moves)
    ? `<button class="go" data-a="continuepractice:${m}">Devam et<small>Yarım kalan maç</small></button>`
    : `<button class="go" disabled style="opacity:.55">Devam et<small>Yarım kalan maç yok</small></button>`;
  const botContinue = practiceButton('bot', botPractice), localContinue = practiceButton('local', localPractice);
  const onlineContinue = onlineResumeRow
    ? `<div class="card"><b>Devam eden çevrimiçi maç</b><p style="margin:7px 0;color:var(--mut)">Rakip: ${esc(onlineResumeRow.white_id===user?.id?onlineResumeRow.black_name:onlineResumeRow.white_name)}</p><button class="go" data-a="continueonline">Maça geri dön</button></div>`
    : '';
  $('#home').innerHTML = `<div class="homehead"><h1>E Chess</h1>${prof ? '' : '<button data-a="login">Giriş / Kayıt</button>'}</div>${top}${prof ? chHTML() : ''}
  <h2>1. Bilgisayara karşı</h2><div class="card"><b>Bilgisayara karşı</b><div class="mode-actions">${botContinue}<button class="go" data-a="bot:1000">Yeni oyun<small>Sıfırdan başla</small></button></div>
  <h2>2. İki kişilik oyun</h2><div class="card"><b>İki kişilik oyun</b><div class="mode-actions">${localContinue}<button class="go" data-a="newlocal">Yeni oyun<small>Sıfırdan başla</small></button></div></div>
  <h2>3. Çevrimiçi oyunlara geri dön</h2>${onlineContinue || '<div class="card"><b>Devam eden çevrimiçi maçlar</b><p class="mu">Şu anda geri dönülebilecek maç bulunmuyor.</p></div>'}
  <h2>Gerçek rakiple oyna</h2><div class="seg">${seg(tc, 'tc')}</div>
  <button class="go" data-a="online">Rakip bul</button><button style="width:100%;margin-top:8px" data-a="friends">👥 Arkadaşlar${nin ? ` <b style="color:var(--g)">(${nin})</b>` : ''}</button><button style="width:100%;margin-top:8px" data-a="lb">Sıralama</button><button style="width:100%;margin-top:8px" data-a="history">📜 Geçmiş maçlar</button>
  <h2>Bilgisayar seviyeleri</h2>` + CATS.map(([n, a]) => `<div style="color:var(--mut);font-size:13px;margin:10px 0 6px">${n}</div><div class="lv">${a.map(r => `<button data-a="bot:${r}">${r}</button>`).join('')}</div>`).join('') +
  `<button style="width:100%;margin-top:14px" data-a="mute">${muted ? '🔇 Ses kapalı' : '🔊 Ses açık'}</button>` +
  `<p style="color:var(--mut);font-size:12px;margin:16px 2px 0">Bot seviyeleri yaklaşık değerlerdir; en yüksek seviyeler tarayıcıdaki motorun gücüyle sınırlıdır.<br>Taş seti: Colin M.L. Burnett (lichess), kral taşı değiştirilmiştir. CC BY-SA 3.0 / GPL.</p>`;
  show('home');
}
async function settingsShow() {
  if (!user || !prof) { show('auth'); return; }
  show('settings');
  const avatar = prof.avatar_url || '';
  $('#settingsprofile').innerHTML = `<div class="card"><div class="profileline" style="margin-bottom:12px">${avatar ? `<img class="avatar" src="${esc(avatar)}" alt="Profil fotoğrafı">` : `<span class="avatar">${esc((prof.display_name||prof.username||'E').slice(0,1).toUpperCase())}</span>`}<span><b>${esc(prof.display_name||prof.username)}</b><br><small style="color:var(--mut)">@${esc(prof.username)}</small></span></div><label>Görünen ad</label><input id="displayname" maxlength="40" value="${esc(prof.display_name||prof.username)}" placeholder="Görünen ad"><label>Hakkımda</label><textarea id="profilebio" maxlength="180" placeholder="Kendinden bahset" style="width:100%;min-height:82px;background:var(--bg);color:var(--fg);border:0;border-radius:10px;padding:12px">${esc(prof.bio||'')}</textarea><label>Profil fotoğrafı bağlantısı</label><input id="avatarurl" value="${esc(avatar)}" placeholder="https://.../foto.jpg" inputmode="url" autocomplete="url"><small class="field-help">HTTPS bağlantısı kullan. Fotoğrafı başka bir yerde barındırıp bağlantısını buraya ekleyebilirsin.</small><button class="go" data-a="profilesave">Profili kaydet</button><div class="mu">ELO ${prof.elo} · ${prof.games||0} maç · ${prof.wins||0} galibiyet</div></div>`;
  $('#settingsmsg').textContent='';
  const theme=localStorage.getItem('echess_theme')||'system'; document.querySelectorAll('[data-a^="theme:"]').forEach(b=>b.classList.toggle('active',b.dataset.a.split(':')[1]===theme));
}

async function lbShow() {
  show('lb');
  const {data} = await sb.from('profiles').select('username,elo').order('elo', {ascending: false}).limit(50);
  $('#lbt').innerHTML = '<tr><th>#</th><th>Oyuncu</th><th>ELO</th></tr>' + (data || []).map((p, i) => `<tr><td>${i + 1}</td><td>${esc(p.username)}</td><td>${p.elo}</td></tr>`).join('');
}

// ===== YENİ EKLENDİ: Oyuncu arama, oyuncu profili/istatistik ve maç geçmişi =====
let previousPlayerView = 'fr';
function gameOpponent(row, uid) {
  const white = row.white_id === uid;
  return {name: white ? row.black_name : row.white_name, id: white ? row.black_id : row.white_id,
    date: row.updated_at || row.created_at};
}
function resultFor(row, uid) {
  if (row.result === 'd') return 'Berabere';
  const won = (row.result === 'w' && row.white_id === uid) || (row.result === 'b' && row.black_id === uid);
  return won ? 'Galibiyet' : 'Mağlubiyet';
}
function gameCard(row, uid) {
  const op = gameOpponent(row, uid), date = op.date ? new Date(op.date).toLocaleString('tr-TR') : '';
  return `<div class="card"><div class="rw"><b>${esc(op.name || 'Bilinmeyen oyuncu')}</b><b>${esc(resultFor(row,uid))}</b></div><div class="mu">${date} · ${esc(row.tc || '?')} dk</div><div style="display:flex;justify-content:flex-end;margin-top:8px"><button data-a="reviewgame" data-id="${esc(row.id)}" style="background:var(--g);color:white;padding:8px 12px;font-weight:700">Maçı incele</button></div></div>`;
}
function practiceCard(row) {
  const date = row.created_at ? new Date(row.created_at).toLocaleString('tr-TR') : '';
  const result = row.result === 'd' ? 'Berabere' : row.mode === 'local' ? (row.result === 'w' ? 'Beyaz kazandı' : 'Siyah kazandı') : ((row.result === (row.white_name === (prof?.username || '') ? 'w' : 'b')) ? 'Galibiyet' : 'Mağlubiyet');
  return `<div class="card"><div class="rw"><b>${esc(row.opponent_name || (row.mode === 'local' ? '2 kişilik maç' : 'Bilgisayar'))}</b><b>${esc(result)}</b></div><div class="mu">${date} · ${row.mode === 'local' ? 'Yerel maç' : 'Bilgisayar maçı'}</div><div style="display:flex;justify-content:flex-end;margin-top:8px"><button data-a="${row.localOnly ? 'reviewlocal' : 'reviewpractice'}" data-id="${esc(row.id)}" style="background:var(--g);color:white;padding:8px 12px;font-weight:700">Maçı incele</button></div></div>`;
}
async function playerShow(id, back='fr') {
  previousPlayerView=back; show('player');
  $('#playername').textContent='Oyuncu profili'; $('#playerstats').textContent='Yükleniyor…'; $('#playergames').innerHTML='';
  const {data:p,error}=await sb.from('profiles').select('id,username,display_name,bio,avatar_url,elo,wins,losses,draws').eq('id',id).maybeSingle();
  if (error || !p) { $('#playerstats').textContent='Oyuncu bulunamadı veya profil görüntüleme izni yok.'; return; }
  $('#playername').textContent=p.display_name||'@'+p.username;
  const played=(+p.wins||0)+(+p.losses||0)+(+p.draws||0), rate=played ? Math.round((+p.wins||0)*100/played) : 0;
  const winRate=played?Math.round((+p.wins||0)*100/played):0,drawRate=played?Math.round((+p.draws||0)*100/played):0,lossRate=played?Math.round((+p.losses||0)*100/played):0;
  $('#playerstats').innerHTML=`<div class="card player-hero"><div class="profileline">${p.avatar_url?`<img class="avatar player-avatar" src="${esc(p.avatar_url)}" alt="">`:`<span class="avatar player-avatar">${esc((p.display_name||p.username||'E').slice(0,1).toUpperCase())}</span>`}<span><b>${esc(p.display_name||p.username)}</b><br><small class="mu" style="margin:0">@${esc(p.username)}</small>${p.bio?`<p class="player-bio">${esc(p.bio)}</p>`:''}</span></div><div class="elo-hero"><span>ELO</span><b>${Number(p.elo)||0}</b></div></div><div class="stats-grid"><div class="card stat-tile"><small>Oynanan</small><b>${played}</b></div><div class="card stat-tile"><small>Galibiyet</small><b>${+p.wins||0}</b></div><div class="card stat-tile"><small>Mağlubiyet</small><b>${+p.losses||0}</b></div><div class="card stat-tile"><small>Beraberlik</small><b>${+p.draws||0}</b></div></div><div class="card"><div class="rw"><b>Sonuç dağılımı</b><b>%${rate} galibiyet</b></div><div class="result-meter"><i style="width:${winRate}%;background:#72b34b"></i><i style="width:${drawRate}%;background:#d2b65a"></i><i style="width:${lossRate}%;background:#d76a62"></i></div><div class="rw mu"><span>🟢 ${winRate}% galibiyet</span><span>🟡 ${drawRate}% beraberlik</span><span>🔴 ${lossRate}% mağlubiyet</span></div></div>`;
  const {data:games}=await sb.from('chess_games').select('id,white_id,black_id,white_name,black_name,white_rating,black_rating,result,status,tc,created_at,updated_at').eq('status','finished').or(`white_id.eq.${id},black_id.eq.${id}`).order('updated_at',{ascending:false}).limit(100);
  const {data:practice}=id===user?.id ? await sb.from('practice_games').select('*').eq('user_id',id).order('created_at',{ascending:false}).limit(100) : {data:[]};
  const results=(games||[]).map(r=>resultFor(r,id));
  let streak=0, bestStreak=0;
  for (const result of results) { if (result==='Galibiyet') { streak++; bestStreak=Math.max(bestStreak,streak); } else streak=0; }
  const badges=[];
  if ((+p.wins||0)>0) badges.push(['🏆','İlk zafer','İlk maç galibiyetini aldın']);
  if (bestStreak>=5) badges.push(['🔥','5 maç serisi','En az 5 maçlık galibiyet serisi']);
  if (played>=100) badges.push(['💯','100 maç','100 tamamlanmış maça ulaştın']);
  const {data:eloHistory}=await sb.from('elo_history').select('elo,recorded_at').eq('user_id',id).order('recorded_at',{ascending:true}).limit(200);
  let eloVals=(eloHistory||[]).map(r=>Number(r.elo)).filter(Number.isFinite),eloLabel='Kaydedilmiş gerçek ELO değişimleri';
  if(!eloVals.length){const eloRows=(games||[]).filter(r=>(id===r.white_id?r.white_rating:r.black_rating)!=null&&Number.isFinite(Number(id===r.white_id?r.white_rating:r.black_rating))).slice().reverse();eloVals=eloRows.map(r=>Number(id===r.white_id?r.white_rating:r.black_rating));eloLabel='Geçmiş maçlardaki maç öncesi ELO değerleri';}
  if(eloVals.length>1){
    const min=Math.min(...eloVals),max=Math.max(...eloVals),span=Math.max(1,max-min),pts=eloVals.map((v,i)=>`${(i/(eloVals.length-1))*300},${90-((v-min)/span)*75}`).join(' ');
    $('#playerstats').innerHTML += `<div class="card"><b>ELO geçmişi</b><div class="mu" style="margin:4px 0 8px">${eloLabel}</div><svg viewBox="0 0 300 100" style="width:100%;height:110px;background:#201f1d;border-radius:8px" preserveAspectRatio="none"><polyline points="${pts}" fill="none" stroke="#81b64c" stroke-width="2.5" vector-effect="non-scaling-stroke"/>${eloVals.map((v,i)=>`<circle cx="${(i/(eloVals.length-1))*300}" cy="${90-((v-min)/span)*75}" r="2.5" fill="#ebecd0"/>`).join('')}</svg><div class="rw mu"><span>${min} ELO</span><span>${max} ELO</span></div></div>`;
  } else $('#playerstats').innerHTML += '<div class="card mu">ELO grafiği için yeterli geçmiş kaydı henüz yok.</div>';
  const buckets={};
  for(const r of (games||[])){
    const side=id===r.white_id?'Beyaz':'Siyah',key=side+' · '+(r.tc||'?')+' dk';
    const b=buckets[key]||(buckets[key]={g:0,m:0,d:0}); const result=resultFor(r,id); b.g+=result==='Galibiyet'?1:0; b.m+=result==='Mağlubiyet'?1:0; b.d+=result==='Berabere'?1:0;
  }
  const bucketRows=Object.entries(buckets).map(([k,v])=>`<div class="rw"><span>${esc(k)}</span><b>${v.g}G · ${v.m}M · ${v.d}B</b></div>`).join('');
  $('#playerstats').innerHTML += `<div class="card"><b>Renk ve süre istatistikleri</b>${bucketRows||'<p class="mu">Henüz veri yok.</p>'}</div>`;
  $('#playerstats').innerHTML += `<div class="card"><b>Başarı rozetleri</b><div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px">${badges.length ? badges.map(([ico,name,desc])=>`<span title="${esc(desc)}" style="border:1px solid var(--line);border-radius:12px;padding:8px 10px">${ico} ${esc(name)}</span>`).join('') : '<span class="mu">Henüz rozet kazanılmadı. İlk galibiyetinle başla!</span>'}</div></div>`;
  const allGames=[...(games||[]).map(r=>({kind:'online',row:r})),...(practice||[]).map(r=>({kind:'practice',row:r}))].sort((a,b)=>new Date(b.row.updated_at||b.row.created_at)-new Date(a.row.updated_at||a.row.created_at));
  $('#playergames').innerHTML=allGames.length ? allGames.map(x=>x.kind==='online'?gameCard(x.row,id):practiceCard(x.row)).join('') : '<p class="mu">Görüntülenebilir maç geçmişi yok.</p>';
}
async function historyShow() {
  show('history'); $('#historylist').textContent='Yükleniyor…';
  if (!user) { let local=[];try{local=JSON.parse(localStorage.getItem('echess_local_games_v1')||'[]')}catch{} $('#historylist').innerHTML=local.length?local.map(practiceCard).join(''):'<p class="mu">Cihazda kayıtlı maç yok.</p>'; return; }
  const {data,error}=await sb.from('chess_games').select('id,white_id,black_id,white_name,black_name,result,status,tc,created_at,updated_at').eq('status','finished').or(`white_id.eq.${user.id},black_id.eq.${user.id}`).order('updated_at',{ascending:false}).limit(100);
  if (error) { $('#historylist').textContent='Maç geçmişi yüklenemedi. chess_games RLS okuma izinlerini kontrol et.'; return; }
  const {data:practice}=await sb.from('practice_games').select('*').eq('user_id',user.id).order('created_at',{ascending:false}).limit(100);
  let local=[];try{local=JSON.parse(localStorage.getItem('echess_local_games_v1')||'[]').filter(x=>!x.user_id||x.user_id===user.id)}catch{}
  const all=[...(data||[]).map(row=>({kind:'online',row})),...(practice||[]).map(row=>({kind:'practice',row})),...local.map(row=>({kind:'local',row}))].sort((a,b)=>new Date(b.row.updated_at||b.row.created_at)-new Date(a.row.updated_at||a.row.created_at));
  $('#historylist').innerHTML=all.length ? all.map(x=>x.kind==='online'?gameCard(x.row,user.id):practiceCard(x.row)).join('') : '<p class="mu">Henüz tamamlanmış maçın yok.</p>';
}

async function auth(up) {
  const u = $('#u').value.trim().toLowerCase(), p = $('#p').value, e = $('#err');
  e.textContent = '';
  if (!/^[a-z0-9_]{3,16}$/.test(u)) return e.textContent = 'Kullanıcı adı 3-16 karakter: a-z, 0-9, _';
  if (p.length < 6) return e.textContent = 'Şifre en az 6 karakter olmalı.';
  let em = u + '@satranc.app';
  let r;
  try {
    if (!up) {
      // Kullanıcı adı değişmiş hesaplarda Supabase Auth e-postası eski adla kalır.
      // Güncel kullanıcı adının giriş e-postasını güvenli eşleme tablosundan bul.
      const alias = await sb.from('username_login_aliases').select('login_email').eq('username', u).maybeSingle();
      if (alias.error) return e.textContent = 'Giriş sistemi güncellenemedi. İnternet bağlantını kontrol et.';
      if (!alias.data?.login_email) return e.textContent = 'Kullanıcı adı veya şifre hatalı.';
      em = alias.data.login_email;
      r = await sb.auth.signInWithPassword({email: em, password: p});
    } else {
      r = await sb.auth.signUp({email: em, password: p, options: {data: {username: u}}});
    }
  } catch { return e.textContent = 'İnternet yok. Giriş için bağlantı gerekli.'; }
  if (r.error) return e.textContent = up ? 'Kayıt olmadı: kullanıcı adı alınmış olabilir.' : 'Kullanıcı adı veya şifre hatalı.';
  if (!r.data.session) return e.textContent = 'Hesap açıldı ama oturum başlamadı. Giriş yapmayı dene.';
  $('#p').value = '';
}

// ===== Arkadaşlar =====
const rpc = async (fn, args) => { try { const r = await sb.rpc(fn, args); return r.error ? {error: r.error} : {data: r.data}; } catch { return {error: {message: 'offline'}}; } };
const rerr = e => !e ? '' : e.message === 'offline' ? 'İnternet yok.' : e.code === 'PGRST202' ? 'Sunucu kurulumu eksik: supabase-arkadas.sql çalıştırılmamış.' : 'İşlem başarısız, tekrar dene.';
const fmsg = (t, ok) => { const e = $('#frm'); e.textContent = t || ''; e.style.color = ok ? 'var(--g)' : '#e5736f'; };
const fId = f => f.requester_id === user.id ? f.addressee_id : f.requester_id;
const fName = f => { const id = fId(f), p = soc.pr[id]; return p ? (p.display_name || p.username || (f.requester_id === user.id ? f.addressee_name : f.requester_name)) : (f.requester_id === user.id ? f.addressee_name : f.requester_name); };

function chHTML() {
  return soc.ch.filter(c => c.to_id === user.id).map(c => `<div class="card"><b>${esc(c.from_name)}</b> seni ${esc(c.tc)} dk'lık maça davet ediyor<div class="row"><button class="go" data-a="chacc:${esc(c.id)}">Kabul</button><button class="go" style="background:#3d3a36" data-a="chdec:${esc(c.id)}">Reddet</button></div></div>`).join('');
}
function frRender() {
  if (!user || !prof) return;
  $('#frch').innerHTML = chHTML();
  const inc = soc.fs.filter(f => f.status === 'pending' && f.addressee_id === user.id);
  const out = soc.fs.filter(f => f.status === 'pending' && f.requester_id === user.id);
  const fl = soc.fs.filter(f => f.status === 'accepted').sort((a, b) => fName(a).localeCompare(fName(b)));
  let h = `<p style="color:var(--mut);font-size:13px;margin:0 2px 4px">Arkadaşların seni <b>${esc(prof.username)}</b> kullanıcı adıyla ekleyebilir.</p><button data-a="shareinvite" style="width:100%;margin:6px 0 10px">WhatsApp ile arkadaş davet et</button>`;
  if (inc.length) h += '<h2>Gelen istekler</h2>' + inc.map(f => `<div class="card rw"><b>${esc(f.requester_name)}</b><span class="fb"><button class="go sm" data-a="frok:${esc(f.id)}">Kabul</button><button class="sm" data-a="frno:${esc(f.id)}">Reddet</button></span></div>`).join('');
  h += '<h2>Arkadaşlarım</h2>' + (fl.length ? fl.map(f => { const p = soc.pr[fId(f)]; return `<div class="card rw"><span><b>${esc(fName(f))}</b>${p ? `<i class="mu">${esc(p.elo)}</i>` : ''}</span><span class="fb"><button class="sm" data-a="player:${esc(fId(f))}">Profil</button><button class="go sm" data-a="chs:${esc(fId(f))}">Meydan oku</button><button class="sm" data-a="frdel:${esc(f.id)}" aria-label="Çıkar">✕</button></span></div>`; }).join('') : '<p style="color:var(--mut);margin:4px 2px">Henüz arkadaşın yok. Yukarıya bir kullanıcı adı yazıp ekle.</p>');
  if (out.length) h += '<h2>Gönderilen istekler</h2>' + out.map(f => `<div class="card rw"><span><b>${esc(f.addressee_name)}</b><i class="mu">yanıt bekleniyor</i></span><button class="sm" data-a="frdel:${esc(f.id)}">İptal</button></div>`).join('');
  $('#frl').innerHTML = h;
  frSearchRender();
}
async function frShow(m) {
  if (!ONLINE_OK || !navigator.onLine) return ask('Arkadaş özellikleri için internet gerekli.', 'Tamam', true);
  if (!user || !prof) { $('#err').textContent = 'Arkadaşlar için giriş yap.'; return show('auth'); }
  show('fr'); $('#frtc').innerHTML = seg(tc, 'ftc'); fmsg(m || ''); frRender(); await socialRefresh(true);
  const inviteName=new URLSearchParams(location.search).get('add'); if(inviteName){$('#fu').value=inviteName; await frSearch(); history.replaceState({},'',location.pathname);}
}
async function socialRefresh(force) {
  if (!user || !ONLINE_OK) return;
  try {
    const [f, c] = await Promise.all([
      sb.from('friendships').select('*'),
      sb.from('friend_challenges').select('*').eq('status', 'pending').gt('created_at', new Date(Date.now() - 125000).toISOString())
    ]);
    if (f.error || c.error) return;
    const fs = f.data || [], ids = fs.filter(x => x.status === 'accepted').map(fId), pr = {};
    if (ids.length) { const {data} = await sb.from('profiles').select('id,username,display_name,elo').in('id', ids); (data || []).forEach(p => pr[p.id] = p); }
    soc = {fs, pr, ch: c.data || []};
  } catch { return; }
  const sig = JSON.stringify(soc);
  if (sig === socSig && !force) return;
  socSig = sig;
  if (view === 'home') home(); else if (view === 'fr') frRender();
}
function socialSub() {
  if (sch || !ONLINE_OK || !user) return;
  try {
    sch = sb.channel('social-' + user.id)
      .on('postgres_changes', {event: '*', schema: 'public', table: 'friend_challenges'}, () => { socialRefresh(); chalCheck(); })
      .on('postgres_changes', {event: '*', schema: 'public', table: 'friendships'}, () => socialRefresh())
      .subscribe();
  } catch { sch = null; }
}
async function socialUnsub() {
  const c = sch; sch = null; soc = {fs: [], pr: {}, ch: []}; socSig = ''; frRes = null;
  if (c) { try { await sb.removeChannel(c); } catch {} }
}
let frRes = null;
async function frSearch() {
  const q = $('#fu').value.trim().replace(/^@/, '').toLowerCase();
  if (q.length < 2) { frRes = null; frSearchRender(); return fmsg('En az 2 karakter yaz.'); }
  fmsg('');
  const {data, error} = await sb.from('profiles').select('id,username,elo').ilike('username', `%${q}%`).neq('id', user?.id || '').order('elo', {ascending: false}).limit(30);
  if (error) return fmsg('Oyuncular yüklenemedi, tekrar dene.');
  frRes = data || [];
  if (!frRes.length) fmsg('Oyuncu bulunamadı.');
  frSearchRender();
}
function frSearchRender() {
  const el = $('#frs'); if (!el) return;
  if (!frRes || !user) { el.innerHTML = ''; return; }
  el.innerHTML = frRes.map(p => {
    const f = soc.fs.find(x => fId(x) === p.id);
    const btn = !f ? `<button class="go sm" data-a="fadd:${esc(p.id)}">Arkadaş ekle</button>`
      : f.status === 'accepted' ? '<button class="sm" disabled>Arkadaşsınız</button>'
      : f.requester_id === user.id ? '<button class="sm" disabled>İstek gönderildi</button>'
      : `<button class="go sm" data-a="frok:${esc(f.id)}">Kabul et</button>`;
    return `<div class="card rw"><span style="min-width:0;overflow:hidden"><b>@${esc(p.username)}</b><i class="mu">${Number(p.elo) || 0}</i></span><span class="fb"><button class="sm" data-a="player:${esc(p.id)}">Profil</button>${btn}</span></div>`;
  }).join('');
}
function frAddId(id) {
  const p = (frRes || []).find(x => x.id === id);
  if (p) frAddName(p.username);
}
async function frAddName(u) {
  if (u === prof.username) return fmsg('Kendini ekleyemezsin :)');
  const r = await rpc('send_friend_request', {p_target: u});
  if (r.error) return fmsg(rerr(r.error));
  const M = {sent: ['İstek gönderildi.', 1], accepted: ['Artık arkadaşsınız!', 1], already: ['Zaten arkadaşsınız.', 0], pending: ['İstek zaten gönderilmiş.', 0], not_found: ['Böyle bir kullanıcı yok.', 0], self: ['Kendini ekleyemezsin :)', 0]}[r.data] || ['İşlem başarısız.', 0];
  fmsg(M[0], M[1]);
  socialRefresh(true);
}
async function sendChal(fid) {
  if (!ONLINE_OK || !navigator.onLine) return ask('Arkadaşınla oynamak için internet gerekli.', 'Tamam', true);
  const f = soc.fs.find(x => x.status === 'accepted' && fId(x) === fid);
  const r = await rpc('send_challenge', {p_friend: fid, p_tc: tc});
  if (r.error || !r.data || r.data.error) return fmsg(r.error ? rerr(r.error) : r.data && r.data.error === 'not_friends' ? 'Önce arkadaş olmalısınız.' : 'Davet gönderilemedi.');
  chal = r.data.id; chalBusy = false;
  show('wait'); $('#wh').textContent = 'Cevap bekleniyor…';
  $('#wtxt').textContent = `${f ? fName(f) : 'Arkadaşın'} · ${tc} dk · davet gönderildi (2 dk geçerli)`;
  clearInterval(chalT); chalT = setInterval(chalCheck, 2000);
}
async function cancelChal() {
  const id = chal; clearInterval(chalT); chal = null;
  if (!id) return null;
  const r = await rpc('cancel_challenge', {p_cid: id});
  return r.data || null;
}
async function chalCheck() {
  if (!chal || chalBusy) return;
  const id = chal; chalBusy = true;
  try {
    const {data: c} = await sb.from('friend_challenges').select('*').eq('id', id).maybeSingle();
    if (chal !== id || !c) return;
    if (c.status === 'accepted' && c.game_id) {
      const {data: gm} = await sb.from('chess_games').select('*').eq('id', c.game_id).maybeSingle();
      if (!gm || chal !== id) return;
      clearInterval(chalT); chal = null; gid = gm.id; started = true; sub(gid); start('online', gm);
    } else if (c.status === 'declined' || c.status === 'cancelled' || (c.status === 'pending' && Date.now() - new Date(c.created_at).getTime() > 125000)) {
      const why = c.status === 'declined' ? c.to_name + ' daveti reddetti.' : c.to_name + ' cevap vermedi, davet sona erdi.';
      await cancelChal(); frShow(why);
    }
  } catch {} finally { chalBusy = false; }
}
async function acceptChal(id) {
  const r = await rpc('accept_challenge', {p_cid: id});
  if (r.error || !r.data) { await ask(r.error ? rerr(r.error) : 'Davet süresi dolmuş ya da iptal edilmiş.', 'Tamam', true); socialRefresh(true); return; }
  gid = r.data.id; started = true; sub(gid); start('online', r.data);
}
$('#fu').addEventListener('keydown', e => { if (e.key === 'Enter') frSearch(); });
setInterval(() => { if (user && document.visibilityState === 'visible' && (view === 'home' || view === 'fr')) socialRefresh(); }, 6000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && user) { socialRefresh(); chalCheck(); } });

// ===== Tıklamalar =====
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const [a, v] = b.dataset.a.split(':');
  if (a === 'tc') { tc = +v; home(); }
  else if (a === 'lb') lbShow();
  else if (a === 'player') playerShow(v, 'fr');
  else if (a === 'mystats') { if (!user) { show('auth'); $('#err').textContent='İstatistiklerini görmek için giriş yap.'; } else playerShow(user.id, 'home'); }
  else if (a === 'history') historyShow();
  else if (a === 'settings') settingsShow();
  else if (a === 'backplayer') { if (previousPlayerView === 'fr') frShow(); else historyShow(); }
  else if (a === 'again') { const m = mode, b = botR; if (m === 'online') { await leave(); findOnline(); } else if (m) start(m, null, b, m === 'bot' ? (my === 'w' ? 'b' : 'w') : undefined); }
  else if (a === 'ovx') { ovDismissed = true; ovUpdate(); draw(); }
  else if (a === 'evaltoggle') { evalPanelShow(!evalEnabled); }
  else if (a === 'mute') { muted = !muted; localStorage.setItem('echess_mute', muted ? '1' : '0'); unlock(); if(view==='settings') settingsShow(); else home(); }
  else if (a === 'login') { $('#err').textContent = ''; show('auth'); }
  else if (a === 'signin') auth(false);
  else if (a === 'signup') auth(true);
  else if (a === 'usernamechange') {
    if (!user || !prof) { await ask('Kullanıcı adını değiştirmek için giriş yapmalısın.', 'Tamam', true); return; }
    const entered = await inputAsk('Yeni kullanıcı adın', '3–16 karakter, a-z, 0–9 ve _ kullanabilirsin.', prof.username || '');
    if (entered === null) return;
    const next = entered.trim().toLowerCase();
    if (!/^[a-z0-9_]{3,16}$/.test(next)) { await ask('Kullanıcı adı 3–16 karakter olmalı; yalnızca küçük harf, rakam ve _ kullanılabilir.', 'Tamam', true); return; }
    if (next === prof.username) return;
    const {data, error} = await sb.from('profiles').update({username: next}).eq('id', user.id).select('*').maybeSingle();
    if (error) { await ask(error.code === '23505' ? 'Bu kullanıcı adı zaten kullanılıyor.' : 'Kullanıcı adı güncellenemedi. Supabase SQL güncellemesini uyguladığından emin ol.', 'Tamam', true); return; }
    if (!data) { await ask('Güncelleme izni bulunamadı. ZIP içindeki supabase/PROFIL_GUNCELLEME.sql dosyasını Supabase SQL Editor’da çalıştır.', 'Tamam', true); return; }
    prof = data; localStorage.setItem('echess_prof', JSON.stringify(prof)); home();
    await ask('Kullanıcı adın güncellendi.', 'Tamam', true);
  }
  else if (a === 'profilesave') {
    const display_name=$('#displayname').value.trim(), bio=$('#profilebio').value.trim(), avatar_url=$('#avatarurl').value.trim();
    if (!display_name || display_name.length>40 || bio.length>180) { $('#settingsmsg').textContent='Görünen ad 1–40, biyografi en fazla 180 karakter olmalı.'; return; }
    if (avatar_url && !/^https:\/\//i.test(avatar_url)) { $('#settingsmsg').textContent='Profil fotoğrafı https:// ile başlayan bir bağlantı olmalı.'; return; }
    const {data,error}=await sb.from('profiles').update({display_name,bio,avatar_url:avatar_url||null}).eq('id',user.id).select('*').maybeSingle();
    if(error||!data){$('#settingsmsg').textContent='Profil kaydedilemedi.';return;} prof=data;localStorage.setItem('echess_prof',JSON.stringify(prof));settingsShow();$('#settingsmsg').textContent='Profil kaydedildi.';
  }
  else if (a === 'theme') { applyTheme(v || 'system'); settingsShow(); }
  else if (a === 'notifsettings') { if (!('Notification' in window)) { await ask('Bu tarayıcı bildirim iznini desteklemiyor.', 'Tamam', true); } else { const p=await Notification.requestPermission(); await ask(p==='granted'?'Bildirim izni verildi.':'Bildirim izni verilmedi.', 'Tamam', true); } }
  else if (a === 'privacy') { const val=localStorage.getItem('echess_show_presence')!=='0'; const yes=await ask(`Son görülme görünürlüğü şu anda ${val?'açık':'kapalı'}. ${val?'Kapatılsın mı?':'Açılsın mı?'}`,'Değiştir'); if(yes){localStorage.setItem('echess_show_presence',val?'0':'1');$('#settingsmsg').textContent='Tercih kaydedildi.';} }
  else if (a === 'deleteaccount') {
    if (!user) return;
    const ok=await ask('Hesabın kalıcı olarak silinecek. Profilin ve hesaba bağlı verilerin silinmesi geri alınamaz. Devam etmek istiyor musun?','Hesabı sil');
    if(!ok)return;
    const second=await ask('Son onay: E Chess hesabını tamamen silmek üzeresin.','Kalıcı olarak sil'); if(!second)return;
    $('#settingsmsg').textContent='Hesap siliniyor…';
    const {data,error}=await sb.functions.invoke('delete-account',{body:{}});
    if(error||!data?.success){$('#settingsmsg').textContent=data?.error||'Hesap silinemedi. Tekrar dene.';return;}
    localStorage.removeItem('echess_prof');localStorage.removeItem(SAVE);await sb.auth.signOut();await ask('Hesabın silindi.','Tamam',true);show('auth');
  }
  else if (a === 'logout') { localStorage.removeItem('echess_prof'); await sb.auth.signOut(); }
  else if (a === 'bot') { pendingBotResolve={rating:+v}; $('#colordlg').classList.remove('hide'); }
  else if (a === 'botcolor') { $('#colordlg').classList.add('hide'); if(pendingBotResolve){const pending=pendingBotResolve;pendingBotResolve=null;if(v!=='cancel')start('bot',null,pending.rating,v==='random'?undefined:v);} }
  else if (a === 'online') findOnline();
  else if (a === 'local' || a === 'newlocal') { start('local'); }
  else if (a === 'continuepractice') restorePractice(v || null);
  else if (a === 'continueonline') { if (onlineResumeRow) { const r=onlineResumeRow; onlineResumeRow=null; gid=r.id; started=true; sub(gid); start('online',r); last=r.last?r.last.split(','):null; draw(); } }
  else if (a === 'flip') { lview = lview === 'w' ? 'b' : 'w'; localNames(); draw(); }
  else if (a === 'markmode') { boardDrawMode=!boardDrawMode; boardMarkFrom=null; $('#markmode').textContent=boardDrawMode?'Çizim açık':'Ok/ kare çiz'; $('#st').textContent=boardDrawMode?'Çizim: bir kareye dokun, sonra hedef kareye dokun. Aynı kareye tekrar dokunarak vurgula.':'Çizim kapalı'; }
  else if (a === 'clearmarks') { boardMarks=[]; boardMarkFrom=null; draw(); }
  else if (a === 'cancel') {
    if (chal) { const id = chal, st = await cancelChal(); if (st === 'accepted') { chal = id; await chalCheck(); return; } frShow(); return; }
    await leave(); home();
  }
  else if (a === 'friends') frShow();
  else if (a === 'shareinvite') { const url=location.origin+'/?add='+encodeURIComponent(prof?.username||''); const text=`E Chess'te bana katıl! Kullanıcı adım @${prof?.username||''}. Arkadaş eklemek için: ${url}`; location.href='https://wa.me/?text='+encodeURIComponent(text); }
  else if (a === 'fsearch') frSearch();
  else if (a === 'fadd') frAddId(v);
  else if (a === 'ftc') { tc = +v; $('#frtc').innerHTML = seg(tc, 'ftc'); frRender(); }
  else if (a === 'frok' || a === 'frno') { const r = await rpc('respond_friend_request', {p_fid: v, p_accept: a === 'frok'}); r.error ? fmsg(rerr(r.error)) : fmsg(a === 'frok' ? 'Arkadaş eklendi.' : 'İstek reddedildi.', a === 'frok'); socialRefresh(true); }
  else if (a === 'frdel') {
    const f = soc.fs.find(x => x.id === v);
    if (f && f.status === 'accepted' && !await ask(fName(f) + ' arkadaşlıktan çıkarılsın mı?', 'Çıkar')) return;
    const r = await rpc('remove_friend', {p_fid: v}); if (r.error) fmsg(rerr(r.error)); else fmsg(''); socialRefresh(true);
  }
  else if (a === 'chs') sendChal(v);
  else if (a === 'chacc') acceptChal(v);
  else if (a === 'chdec') { await rpc('decline_challenge', {p_cid: v}); socialRefresh(true); }
  else if (a === 'home') {
    if (mode === 'online' && started && !over) { if (!await ask('Oyun sürüyor. Menüye dönersen çekilmiş sayılırsın.', 'Menüye dön')) return; await resign(true); }
    await leave(); home();
  }
  else if (a === 'resign') { if (!over && (mode === 'bot' || await ask(mode === 'local' ? (g.turn() === 'w' ? 'Beyaz' : 'Siyah') + ' çekilsin mi?' : 'Çekilmek istediğine emin misin?', 'Çekil'))) resign(); }
  else if (a === 'abortmatch') { if(mode==='online'&&!over&&opponentOnline===false&&g?.history().length===1&&g.turn()!==my&&Date.now()-new Date(row0?.turn_ts||recv).getTime()>=60000){const {data,error}=await sb.functions.invoke('abort-unplayed-game',{body:{gid}});if(error||!data?.ok){msg=data?.error||'İptal doğrulanamadı.';draw();}else{over=true;endRes='d';endWhy='İlk hamlede iptal · ELO değişmedi';msg=endWhy;clearInterval(tick);clearInterval(presenceTimer);localStorage.removeItem(SAVE);draw();}} }
  else if (a === 'claimwin') { if(mode==='online'&&!over&&opponentOnline===false&&g?.history().length>=2&&g.turn()!==my&&Date.now()-new Date(row0?.turn_ts||recv).getTime()>=90000){const {data,error}=await sb.functions.invoke('claim-offline-win',{body:{gid}});if(error||!data?.ok){msg=data?.error||'Galibiyet talebi doğrulanamadı.';draw();}else{over=true;endRes=my;endWhy='Rakip bağlantısı kesildi · Galibiyet';msg=endWhy;clearInterval(tick);clearInterval(presenceTimer);localStorage.removeItem(SAVE);draw();}} }
  else if (a === 'reviewgame') {
    try {
      const {data,error}=await sb.from('chess_games').select('move_history,white_id').eq('id',v).maybeSingle();
      if(error || !data || !data.move_history) return ask('Bu maçın hamle kaydı bulunamadı; inceleme açılamadı.', 'Tamam', true);
      let moves=data.move_history;
      if(typeof moves==='string'){try{moves=JSON.parse(moves)}catch{}}
      if(!Array.isArray(moves)) return ask('Maçın hamle verisi okunamadı.', 'Tamam', true);
      const c=new Chess();
      for(const mv of moves){const ok=c.move(typeof mv==='string'?mv:(mv.san?mv.san:mv));if(!ok)throw new Error('invalid move')}
      if(!c.history().length) return ask('Bu maçta incelenecek hamle yok.', 'Tamam', true);
      location.href='/review.html?pgn='+encodeURIComponent(c.pgn())+'&mine='+(data.white_id===user?.id?'w':'b');
    } catch(e) { ask('Maç incelemeye hazırlanırken hata oluştu.', 'Tamam', true); }
  }
  else if (a === 'reviewlocal') { let arr=[];try{arr=JSON.parse(localStorage.getItem('echess_local_games_v1')||'[]')}catch{} const rec=arr.find(x=>x.id===v); if(!rec?.pgn)return ask('Cihazdaki maç kaydı bulunamadı.','Tamam',true); location.href='./review.html?pgn='+encodeURIComponent(rec.pgn)+(rec.mode==='bot'?'&mine='+(rec.white_name===(prof?.username||'Sen')?'w':'b'):''); }
  else if (a === 'reviewpractice') {
    const {data,error}=await sb.from('practice_games').select('moves,pgn,white_name').eq('id',v).eq('user_id',user?.id).maybeSingle();
    if(error || !data) return ask('Bu maçın kaydı bulunamadı.', 'Tamam', true);
    if(data.pgn) { location.href='/review.html?pgn='+encodeURIComponent(data.pgn)+(data.mode==='bot'?'&mine='+(data.white_name===(prof?.username||'')?'w':'b'):''); return; }
    try { const c=new Chess(); for(const san of (data.moves||[])) c.move(san); location.href='/review.html?pgn='+encodeURIComponent(c.pgn())+(data.mode==='bot'?'&mine='+(data.white_name===(prof?.username||'')?'w':'b'):''); } catch { ask('Maç kaydı okunamadı.', 'Tamam', true); }
  }
  else if (a === 'pgn') pgnExport();
  else if (a === 'analyze') analyze();
  else if (a === 'hint') hintGo();
  else if (a === 'draw') {
    if (mode !== 'online' || over || !started || drawOff === my) return;
    try { const {data} = await sb.rpc('offer_draw', {p_gid: gid}); if (data === true) { drawOff = my; draw(); } else ask('Şu an beraberlik teklif edemezsin. Rakip bu pozisyonda reddetmiş olabilir; bir hamle sonra tekrar dene.', 'Tamam', true); }
    catch { ask('Bağlantı hatası.', 'Tamam', true); }
  }
  else if (a === 'rematch') {
    if (mode !== 'online' || !over || rmWait) return;
    try {
      const {data} = await sb.rpc('request_rematch', {p_gid: gid});
      if (data && data.game_id) joinNext(data.game_id);
      else if (data && data.waiting) { rmWait = true; ovUpdate(); }
      else ask('Rövanş şu an başlatılamadı. Birkaç saniye sonra tekrar dene.', 'Tamam', true);
    } catch { ask('Bağlantı hatası.', 'Tamam', true); }
  }
  else if (a === 'pwchange') { $('#np').value = ''; $('#np2').value = ''; $('#perr').textContent = ''; show('pw'); }
  else if (a === 'pwsave') {
    const p1 = $('#np').value, p2 = $('#np2').value, e = $('#perr'); e.style.color = '#e5736f';
    if (p1.length < 6) { e.textContent = 'Şifre en az 6 karakter olmalı.'; return; }
    if (p1 !== p2) { e.textContent = 'Şifreler aynı değil.'; return; }
    try {
      const r = await sb.auth.updateUser({password: p1});
      if (r.error) { e.textContent = 'Şifre değiştirilemedi. Çıkış yapıp tekrar giriş yaptıktan sonra dene.'; return; }
      e.style.color = 'var(--g)'; e.textContent = 'Şifren değiştirildi.'; $('#np').value = ''; $('#np2').value = '';
    } catch { e.textContent = 'İnternet yok. Şifre değiştirmek için bağlantı gerekli.'; }
  }
  else if (a === 'promo') { const m = pend; pend = null; $('#pr').classList.add('hide'); if (m) doMove({from: m.from, to: m.to, promotion: v}); }
  else if (a === 'prev' || a === 'next' || a === 'first' || a === 'live') {
    if (!g) return;
    const n = g.history().length, cur = vi == null ? n : vi;
    let t = a === 'prev' ? cur - 1 : a === 'next' ? cur + 1 : a === 'first' ? 0 : n;
    t = Math.max(0, Math.min(n, t)); vi = t >= n ? null : t; sel = null; tg = []; if (over && !ovDismissed) ovDismissed = true;   // maç bitmişse sonuç kartı tahtayı kapatmasın
    draw();
  }
  else if (a === 'undo' && mode === 'local') {
    if (g.history().length) { vi = null; g.undo(); const h = g.history({verbose: true}), l = h[h.length - 1]; last = l ? [l.from, l.to] : null; over = false; msg = ''; endRes = null; endWhy = ''; ovDismissed = false; sel = null; tg = []; savePracticeSnapshot(); draw(); }
  }
  else if (a === 'undo') { if (mode === 'bot' && !over && g.turn() === my && g.history().length >= 2) { vi = null; g.undo(); g.undo(); last = null; sel = null; tg = []; savePracticeSnapshot(); draw(); } }
});
function premoveOptions(square) {
  try { const parts=g.fen().split(' '); parts[1]=my; const temp=new Chess(parts.join(' ')); return temp.moves({square,verbose:true}); } catch { return []; }
}
function queuePremove(from,to) {
  const legal=premoveOptions(from).find(x=>x.to===to); if(!legal) return false;
  premove={from,to,promotion:legal.promotion||null}; sel=null; tg=[]; draw(); return true;
}
$('#bd').onclick = e => {
  if (Date.now() - dragEnd < 150) return;
  if(boardDrawMode){const sq=e.target.closest('.sq');if(!sq)return;const target=sq.dataset.s;if(!boardMarkFrom){boardMarkFrom=target;boardMarks.push({from:target,to:target,color:'#e6c84f'});}else{const from=boardMarkFrom;boardMarks=boardMarks.filter(m=>!(m.from===from&&m.to===from));boardMarks.push({from,to:target,color:'#e6c84f'});boardMarkFrom=null;}draw();return;}   // sürüklemenin ardından gelen sahte tık
  const q = e.target.closest('.sq');
  if (pend) { pend = null; $('#pr').classList.add('hide'); }
  if (vi != null) { if (over) return; vi = null; sel = null; tg = []; draw(); return; }   // bitmiş maçta tahtaya dokunmak geçmiş gezintisini bozmaz
  if (!q || over || hintBusy) return;
  const s = q.dataset.s;
  if (g.turn() !== mine()) {
    if (mode === 'local') return;
    if (sel && tg.some(x=>x.to===s)) return queuePremove(sel,s);
    const p=g.get(s); if(p && p.color===my) { sel=s; tg=premoveOptions(s); draw(); }
    else { sel=null; tg=[]; draw(); }
    return;
  }
  const ms2 = tg.filter(x => x.to === s), m = ms2[0];
  if (sel && m) {
    if (m.promotion) { pend = m; $('#pr').innerHTML = ['q','r','b','n'].map(x => `<button data-a="promo:${x}"><img src="${PC}${mine()}${x.toUpperCase()}.svg" alt=""></button>`).join(''); $('#pr').classList.remove('hide'); return; }
    return doMove(m);
  }
  const p = g.get(s);
  if (p && p.color === mine()) { sel = s; tg = g.moves({square: s, verbose: true}); } else { sel = null; tg = []; }
  draw();
};

// ===== Kendi diyalog penceremiz (tarayıcının "site adresi mesajı" yerine "E Chess") =====
function inputAsk(title, help, initial='') {
  return new Promise(resolve => {
    const modal=$('#inputdlg'), input=$('#inputvalue');
    $('#inputtitle').textContent=title; $('#inputhelp').textContent=help; input.value=initial;
    modal.classList.remove('hide'); setTimeout(()=>input.focus(),80);
    const finish=value=>{modal.classList.add('hide');$('#inputok').onclick=null;$('#inputcancel').onclick=null;input.onkeydown=null;resolve(value);};
    $('#inputok').onclick=()=>finish(input.value); $('#inputcancel').onclick=()=>finish(null);
    input.onkeydown=e=>{if(e.key==='Enter')finish(input.value);if(e.key==='Escape')finish(null);};
  });
}

function ask(text, okLabel, alertOnly, noLabel) {
  return new Promise(res => {
    $('#dtxt').textContent = text; $('#dyes').classList.remove('hide'); $('#dyes').textContent = okLabel || 'Tamam'; $('#dno').textContent = noLabel || 'İptal'; $('#dno').classList.toggle('hide', !!alertOnly);
    $('#dlg').classList.remove('hide');
    const done = v => { askCancel = () => {}; $('#dlg').classList.add('hide'); res(v); };
    askCancel = () => done(false);
    $('#dyes').onclick = () => done(true); $('#dno').onclick = () => done(false);
  });
}

// ===== Oyun =====
const mine = () => mode === 'local' ? g.turn() : my;   // 2 kişilik modda sırası gelen taraf
function localNames() { $('#opp').textContent = lview === 'w' ? 'Siyah' : 'Beyaz'; $('#me').textContent = lview === 'w' ? 'Beyaz' : 'Siyah'; }
function start(m, r, bot, col) {
  clearTimeout(waitTimeout); waitTimeout = null; premove = null; practiceSaved = false; boardMarks=[]; boardMarkFrom=null; boardDrawMode=false;
  vi = null; clearTimeout(evalTimer); evalSeq++; mode = m; over = false; msg = ''; const ab=$('#abortmatch');if(ab)ab.classList.add('hide');const cw=$('#claimwin');if(cw)cw.classList.add('hide'); sel = null; tg = []; last = null; ending = false; pend = null; ovDismissed = false; endRes = null; endWhy = ''; $('#ov').classList.add('hide'); noEngine = false; pushing = 0; clearTimeout(finTimer); $('#pr').classList.add('hide'); g = new Chess();
  $('#fl').classList.toggle('hide', m !== 'local'); $('#hi').classList.toggle('hide', m === 'online'); $('#dr').classList.toggle('hide', m !== 'online');
  hint = null; drawOff = null; rmWait = false; rmFrom = null; anTok++; drawTok++; if (dlgDraw) askCancel();
  if (m === 'local') {
    my = 'w'; lview = 'w'; localNames();
    $('#ct').classList.add('hide'); $('#cb').classList.add('hide'); $('#un').classList.remove('hide');
  } else if (m === 'bot') {
    botR = bot; my = col || (Math.random() < .5 ? 'w' : 'b');
    $('#opp').innerHTML = `Bilgisayar<i>${bot}</i>`; $('#me').textContent = prof ? prof.username : 'Sen';
    $('#ct').classList.add('hide'); $('#cb').classList.add('hide'); $('#un').classList.remove('hide');
  } else {
    my = r.white_id === user.id ? 'w' : 'b'; row0 = r; sync(r); localStorage.setItem(SAVE, r.id);
    eloTc = r.tc; eloBefore = prof ? prof.elo : null; eloNow = null; eloAsked = false; presenceSync();
    // YENİ: güvenilir SAN geçmişini yükle; geçmişi olmayan eski aktif maçlar sadece FEN ile açılır.
    if (Array.isArray(r.move_history) && r.move_history.length) {
      try { for (const san of r.move_history) g.move(san); } catch { g = new Chess(r.fen); }
    } else if (r.fen && r.fen !== new Chess().fen()) g = new Chess(r.fen);
    const w = my === 'w';
    $('#opp').innerHTML = `${esc(w ? r.black_name : r.white_name)}<i>${esc(w ? r.black_rating : r.white_rating)}</i>`;
    $('#me').innerHTML = `${esc(prof.username)}<i>${esc(prof.elo)}</i>`;
    $('#ct').classList.remove('hide'); $('#cb').classList.remove('hide'); $('#un').classList.add('hide');
    clearInterval(tick); tick = setInterval(clocks, 250);
  }
  show('game'); draw(); if (m === 'online') drawState(r);
  if (m !== 'online') savePracticeSnapshot();
  if (m === 'bot' && g.turn() !== my && !restoringPractice) botMove();
}
function sqEl(s) { return document.querySelector('#bd .sq[data-s="' + s + '"]'); }
function animateMove(from, to, cb) {
  const fromEl = sqEl(from), toEl = sqEl(to);
  if (!fromEl || !toEl) { cb && cb(); return; }
  const img = fromEl.querySelector('img.p');
  if (!img) { cb && cb(); return; }
  const fr = fromEl.getBoundingClientRect(), tr = toEl.getBoundingClientRect(), br = $('#bd').getBoundingClientRect();
  const clone = img.cloneNode(true);
  clone.className = 'p anim';
  clone.style.cssText = `position:absolute;left:${fr.left-br.left}px;top:${fr.top-br.top}px;width:${fr.width}px;height:${fr.height}px;z-index:20;pointer-events:none;transition:transform .38s cubic-bezier(.3,.7,.3,1);`;
  $('#bd').style.position = 'relative';
  $('#bd').appendChild(clone);
  img.style.opacity = '0';
  void clone.offsetWidth; // geçişin kesin başlaması için
  requestAnimationFrame(() => {
    clone.style.transform = `translate(${tr.left-fr.left}px,${tr.top-fr.top}px)`;
  });
  setTimeout(() => { clone.remove(); cb && cb(); }, 400);
}
// ===== Yenen taşlar + malzeme farkı =====
const PVAL = {p: 1, n: 3, b: 3, r: 5, q: 9}, PINIT = {p: 8, n: 2, b: 2, r: 2, q: 1};
function capInfo() {
  const cnt = {w: {p: 0, n: 0, b: 0, r: 0, q: 0}, b: {p: 0, n: 0, b: 0, r: 0, q: 0}};
  for (const rw of g.board()) for (const p of rw) if (p && p.type !== 'k') cnt[p.color][p.type]++;
  const lost = {}, mat = {};
  for (const c of ['w', 'b']) {
    let promo = 0; lost[c] = {}; mat[c] = 0;
    for (const t of 'nbrq') promo += Math.max(0, cnt[c][t] - PINIT[t]);
    for (const t of 'pnbrq') { lost[c][t] = Math.max(0, PINIT[t] - cnt[c][t]); mat[c] += cnt[c][t] * PVAL[t]; }
    lost[c].p = Math.max(0, lost[c].p - promo);
  }
  return {lost, mat};
}
function capHTML(by) { // 'by' rengi, karşı tarafın yediği taşlar
  const {lost, mat} = capInfo(), vic = by === 'w' ? 'b' : 'w', diff = mat[by] - mat[vic];
  let h = '';
  for (const t of 'qrbnp') if (lost[vic][t]) h += '<span class="g">' + `<img alt="" src="${PC}${vic}${t.toUpperCase()}.svg">`.repeat(lost[vic][t]) + '</span>';
  return h + (diff > 0 ? `<b>+${diff}</b>` : '');
}
function capDraw() {
  const bot = mode === 'local' ? lview : my, top = bot === 'w' ? 'b' : 'w';
  $('#capo').innerHTML = capHTML(top); $('#capm').innerHTML = capHTML(bot);
}
function evalPanelUpdate(cp, turn, seq) {
  if (seq !== evalSeq || !evalEnabled) return;
  const whiteCp = turn === 'w' ? cp : -cp;
  // Centipawn değerini yaklaşık kazanma olasılığına dönüştürür; beraberlik oranı ayrıca modellenmez.
  const white = Math.max(1, Math.min(99, Math.round(100 / (1 + Math.exp(-whiteCp / 400)))));
  const black = 100 - white;
  $('#evalw').textContent = `Beyaz %${white}`;
  $('#evalb').textContent = `Siyah %${black}`;
  $('#evalwhite').style.width = white + '%';
  $('#evalblack').style.width = black + '%';
}
function evalPanelShow(on) {
  evalEnabled = !!on; localStorage.setItem('echess_evalbar', evalEnabled ? '1' : '0');
  $('#evalpanel').classList.toggle('on', evalEnabled);
  $('#evaltoggle').textContent = 'Kazanma olasılığı: ' + (evalEnabled ? 'Açık' : 'Kapalı');
  if (evalEnabled && g) scheduleEval(); else { clearTimeout(evalTimer); evalSeq++; }
}
function scheduleEval() {
  clearTimeout(evalTimer); const seq = ++evalSeq;
  if (!evalEnabled || !g || !mode || over || vi != null) return;
  const fen = g.fen(), turn = g.turn();
  evalTimer = setTimeout(async () => {
    // Botun kendi Stockfish aramasıyla aynı anda değerlendirme başlatma.
    if (mode === 'bot' && turn !== my) return;
    if (!await engine() || seq !== evalSeq || !evalEnabled || g.fen() !== fen) return;
    try {
      const result = await sfEval(fen, 250);
      if (result.cp != null && seq === evalSeq && g.fen() === fen) evalPanelUpdate(result.cp, turn, seq);
    } catch (e) { console.warn('Pozisyon değerlendirmesi yapılamadı', e); }
  }, 900);
}
function draw() {
  let V = g, last2 = last;
  if (vi != null) {
    const H = g.history({verbose: true});
    if (vi >= H.length) vi = null;
    else { let f; try { f = g.header().FEN; } catch {} V = f ? new Chess(f) : new Chess(); for (let i = 0; i < vi; i++) V.move(H[i].san); last2 = vi > 0 ? [H[vi - 1].from, H[vi - 1].to] : null; }
  }
  const b = V.board(), flip = (mode === 'local' ? lview : my) === 'b', set = new Set(vi != null ? [] : tg.map(m => m.to));
  let ks = null;
  if (V.inCheck()) for (const rw of b) for (const p of rw) if (p && p.type === 'k' && p.color === V.turn()) ks = p.square;
  let h = '';
  for (let j = 0; j < 64; j++) {
    const r = flip ? 7 - (j >> 3) : j >> 3, c = flip ? 7 - (j & 7) : j & 7, s = 'abcdefgh'[c] + (8 - r), p = b[r][c];
    let cl = 'sq ' + ((r + c) % 2 ? 'd' : 'l');
    if (last2 && (last2[0] === s || last2[1] === s)) cl += ' h';
    if (s === sel && vi == null) cl += ' s'; if (s === ks) cl += ' k';
    if (premove && (s === premove.from || s === premove.to)) cl += ' hn';
    if (vi == null && hint && hint.fen === g.fen() && (hint.from === s || hint.to === s)) cl += ' hn';
    if (set.has(s)) cl += ' t' + (p ? ' c' : '');
    h += `<div class="${cl}" data-s="${s}">${(j & 7) === 0 ? `<span class="co ra">${8 - r}</span>` : ''}${j >= 56 ? `<span class="co fi">${'abcdefgh'[c]}</span>` : ''}${p ? `<img class="p" draggable="false" src="${PC}${p.color}${p.type.toUpperCase()}.svg">` : ''}</div>`;
  }
  const xy=s=>{const c='abcdefgh'.indexOf(s[0]),r=8-Number(s[1]);return flip?[7-c+.5,7-r+.5]:[c+.5,r+.5]};
  let overlay=''; if(vi==null && hint && hint.fen===g.fen()){const [hx1,hy1]=xy(hint.from),[hx2,hy2]=xy(hint.to);overlay+=`<line x1='${hx1}' y1='${hy1}' x2='${hx2}' y2='${hy2}' stroke='#36a3ff' stroke-width='.18' stroke-linecap='round' opacity='.95'/><polygon points='${hx2},${hy2} ${hx2-.28},${hy2-.2} ${hx2-.2},${hy2-.28}' fill='#36a3ff'/>`;} for(const mk of boardMarks){const [x1,y1]=xy(mk.from),[x2,y2]=xy(mk.to);if(mk.from===mk.to)overlay+=`<rect x='${x1-.45}' y='${y1-.45}' width='.9' height='.9' rx='.08' fill='${mk.color}' opacity='.42'/>`;else overlay+=`<line x1='${x1}' y1='${y1}' x2='${x2}' y2='${y2}' stroke='${mk.color}' stroke-width='.16' stroke-linecap='round' opacity='.8'/><polygon points='${x2},${y2} ${x2-.25},${y2-.18} ${x2-.18},${y2-.25}' fill='${mk.color}'/>`;}
  $('#bd').innerHTML = h + `<svg viewBox='0 0 8 8' style='position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:6'>${overlay}</svg>`; $('#st').textContent = (vi != null ? `Geçmiş: ${vi}/${g.history().length}. hamle · güncele dönmek için tahtaya dokun` : stat()) + (premove ? ' · ön hamle hazır' : '') + (mode === 'online' && !over && drawOff === my ? ' · beraberlik teklifin bekleniyor' : '') + (mode && over && ovDismissed ? ' · sonuç için dokun' : ''); capDraw(); clocks(); ovUpdate(); mlDraw(); drBtn();
}
// ===== Oyun sonu bilgilendirmesi =====
function resultInfo() {
  if (mode === 'local') {
    let win = null, why = '';
    if (g.isCheckmate()) { win = g.turn() === 'w' ? 'b' : 'w'; why = 'Şah mat'; }
    else if (g.isStalemate()) why = 'Pat: oynayacak yasal hamle kalmadı';
    else if (g.isInsufficientMaterial()) why = 'Yetersiz materyal';
    else if (g.isThreefoldRepetition()) why = 'Aynı pozisyon üç kez tekrarlandı';
    else if (g.isDraw()) why = '50 hamle kuralı';
    else { win = endRes; why = endWhy; }
    return {t: win === 'w' ? '🏆 Beyaz kazandı' : win === 'b' ? '🏆 Siyah kazandı' : '🤝 Berabere', w: why};
  }
  let res, why;
  if (g.isCheckmate()) { res = g.turn() === my ? 'l' : 'w'; why = 'Şah mat'; }
  else if (g.isStalemate()) { res = 'd'; why = 'Pat: oynayacak yasal hamle kalmadı'; }
  else if (g.isInsufficientMaterial()) { res = 'd'; why = 'Yetersiz materyal'; }
  else if (g.isThreefoldRepetition()) { res = 'd'; why = 'Aynı pozisyon üç kez tekrarlandı'; }
  else if (g.isDraw()) { res = 'd'; why = '50 hamle kuralı'; }
  else {
    res = endRes === 'd' ? 'd' : endRes === my ? 'w' : 'l';
    why = endWhy || (res === 'w' ? 'Rakip çekildi ya da süresi bitti' : res === 'l' ? 'Çekildin ya da süren bitti' : 'Berabere');
  }
  return {t: res === 'w' ? '🏆 Kazandın!' : res === 'l' ? 'Kaybettin' : '🤝 Berabere', w: why};
}
async function getElo(retry) {
  try {
    const {data} = await sb.from('profiles').select('*').eq('id', user.id).maybeSingle();
    if (!data) { eloNow = false; }
    else {
      prof = data; eloNow = data.elo;
      // sunucu puanı henüz yazmadıysa bir kez daha dene
      if (retry && eloBefore != null && eloNow === eloBefore && endRes !== 'd') { setTimeout(() => getElo(false), 1500); }
    }
  } catch { eloNow = false; }
  if (mode === 'online') ovUpdate();
}
function ovUpdate() {
  const show = !!mode && over && !ovDismissed && !!g;
  $('#ov').classList.toggle('hide', !show);
  if (show) {
    const i = resultInfo(); $('#ovt').textContent = i.t; $('#ovr').textContent = i.w;
    $('#ova').textContent = mode === 'online' ? 'Yeni rakip bul' : mode === 'bot' ? 'Rövanş (renkler değişir)' : 'Tekrar oyna';
    $('#ova').style.background = mode === 'online' ? 'var(--bg)' : '';
    const rb = $('#ovrm'); rb.classList.toggle('hide', mode !== 'online'); rb.disabled = rmWait;
    rb.textContent = rmWait ? 'Rövanş bekleniyor…' : rmFrom ? 'Rakip rövanş istiyor: kabul et' : 'Rövanş';
    const e = $('#ove');
    if (mode === 'online' && eloNow !== false && eloBefore != null) {
      if (eloNow == null) { e.textContent = 'Elo güncelleniyor…'; e.style.color = 'var(--mut)'; }
      else { const d = eloNow - eloBefore; e.textContent = `Elo ${eloBefore} → ${eloNow} (${d >= 0 ? '+' : ''}${d})`; e.style.color = d > 0 ? 'var(--g)' : d < 0 ? '#e5534b' : 'var(--mut)'; }
    } else e.textContent = '';
  }
}
$('#st').onclick = () => { if (mode && over) { ovDismissed = false; ovUpdate(); } };
function stat() {
  if (msg) return msg;
  if (mode === 'local') {
    if (g.isCheckmate()) return 'Şah mat. ' + (g.turn() === 'w' ? 'Siyah' : 'Beyaz') + ' kazandı.';
    if (g.isDraw()) return 'Berabere.';
    return (g.inCheck() ? 'Şah! ' : '') + (g.turn() === 'w' ? 'Beyazın' : 'Siyahın') + ' sırası';
  }
  if (g.isCheckmate()) return g.turn() === my ? 'Şah mat. Kaybettin.' : 'Şah mat. Kazandın.';
  if (g.isDraw()) return 'Berabere.';
  return (g.inCheck() ? 'Şah! ' : '') + (g.turn() === my ? 'Sıra sende' : 'Rakip düşünüyor…') + (noEngine && mode === 'bot' ? ' · Stockfish açılamadı (' + (window.__sfErr || '?') + '), yedek motor oynuyor' : '');
}
function savePracticeSnapshot() {
  if (!g || !['bot','local'].includes(mode) || over || !g.history().length && !mode) return;
  try { const snap=JSON.stringify({mode, botR, my, moves:g.history(), updated_at:Date.now()}); localStorage.setItem(practiceKey(mode),snap); localStorage.setItem(PRACTICE_SAVE,snap); } catch {}
}
function restorePractice(which) {
  let snap = which ? readPractice(which) : readPractice('bot') || readPractice('local');
  if (!snap || !['bot','local'].includes(snap.mode) || !Array.isArray(snap.moves) || snap.moves.length > 1000 || !Number.isFinite(Number(snap.updated_at))) { ask('Devam edilecek kayıt bulunamadı veya kayıt geçersiz.','Tamam',true); return; }
  restoringPractice=true;
  start(snap.mode,null,snap.botR,snap.my);
  try { for (const san of (snap.moves||[])) g.move(san); }
  catch { restoringPractice=false; localStorage.removeItem(practiceKey(snap.mode)); localStorage.removeItem(PRACTICE_SAVE); ask('Kayıt bozuk olduğu için devam edilemiyor.','Tamam',true); return; }
  restoringPractice=false; over=g.isGameOver(); savePracticeSnapshot(); last=null;
  const h=g.history({verbose:true}); if(h.length) last=[h[h.length-1].from,h[h.length-1].to];
  draw(); if(mode==='bot' && !over && g.turn()!==my) botMove();
}
function resumePractice() {
  if (mode || gid || view !== 'home') return;
  const snap = readPractice('bot') || readPractice('local');
  if (snap && Array.isArray(snap.moves)) home();
}

function doMove(m) {
  vi = null;
  const from = m.from, to = m.to;
  const res = g.move({from, to, promotion: m.promotion});
  last = [from, to]; sel = null; tg = [];
  if ((mode === 'bot' || mode === 'local') && g.isGameOver()) over = true;
  if (mode !== 'online' && !over) savePracticeSnapshot();
  if (over) { try { localStorage.removeItem(practiceKey(mode)); localStorage.removeItem(PRACTICE_SAVE); } catch {} }
  draw();                      // kendi hamlen anında görünür
  playMove(!!res.captured, g.inCheck());
  if (mode === 'online') push();
  else if (over) savePracticeGame();
  else if (mode === 'bot') {
    const queued=premove;
    if (queued && g.turn() === my) { premove=null; const legal=g.moves({verbose:true}).find(x=>x.from===queued.from && x.to===queued.to); if (legal) doMove({...legal,promotion:queued.promotion||legal.promotion}); else draw(); }
    else botMove();
  }
}
async function savePracticeGame() {
  if (practiceSaved || !g || !['bot','local'].includes(mode) || !g.history().length) return;
  practiceSaved = true; let result='d';
  if (g.isCheckmate()) result = g.turn()==='w'?'b':'w'; else if (endRes==='w' || endRes==='b') result=endRes;
  const whiteName=mode==='bot'?(my==='w'?(prof?.username||'Sen'):'Bilgisayar '+botR):'Beyaz';
  const blackName=mode==='bot'?(my==='b'?(prof?.username||'Sen'):'Bilgisayar '+botR):'Siyah';
  const record={id:'local-'+Date.now(),localOnly:true,user_id:user?.id||null,mode,opponent_name:mode==='bot'?'Bilgisayar '+botR:'2 kişilik maç',tc:0,white_name:whiteName,black_name:blackName,result,moves:g.history(),pgn:pgnText(),created_at:new Date().toISOString()};
  try{const arr=JSON.parse(localStorage.getItem('echess_local_games_v1')||'[]');arr.unshift(record);localStorage.setItem('echess_local_games_v1',JSON.stringify(arr.slice(0,100)));}catch(e){console.warn('Local match archive failed',e);}
  if(!user)return;
  try{const {error}=await sb.from('practice_games').insert({user_id:user.id,mode,opponent_name:record.opponent_name,tc:0,white_name:whiteName,black_name:blackName,result,moves:record.moves,pgn:record.pgn});if(error)console.warn('Practice game cloud save failed',error);}catch(e){console.warn('Practice game cloud save failed',e);}
}
async function resign(quiet) {
  if (over) return; over = true;
  if (mode === 'local') { try { localStorage.removeItem(practiceKey(mode)); localStorage.removeItem(PRACTICE_SAVE); } catch {} const sd = g.turn(); endRes = sd === 'w' ? 'b' : 'w'; endWhy = (sd === 'w' ? 'Beyaz' : 'Siyah') + ' çekildi'; msg = endWhy + '.'; savePracticeGame(); draw(); return; }
  if (mode === 'bot') { try { localStorage.removeItem(practiceKey(mode)); localStorage.removeItem(PRACTICE_SAVE); } catch {} }
  msg = 'Çekildin.'; endRes = my === 'w' ? 'b' : 'w'; endWhy = 'Çekildin';
  if (mode === 'online') await endGame(my === 'w' ? 'b' : 'w', 'resign'); else await savePracticeGame();
  if (!quiet) draw();
}

// ===== Süre =====
const fmt = t => { t = Math.max(0, Math.ceil(t / 1000)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
function rem(c) { return ms[c] - (!over && g.turn() === c ? Date.now() - recv : 0); }
function tForClock(){return g ? g.turn() : 'w';}
function clocks() {
  if (mode !== 'online' || !g) return;
  const idleMs=Date.now()-new Date(row0?.turn_ts||recv).getTime();
  const abortReady=!over&&started&&opponentOnline===false&&g.history().length===1&&g.turn()!==my&&idleMs>=60000;
  const claimReady=!over&&started&&g.history().length>=2&&g.turn()!==my&&opponentOnline===false&&idleMs>=90000;
  const abortBtn=$('#abortmatch'); if(abortBtn)abortBtn.classList.toggle('hide',!abortReady);
  const claimBtn=$('#claimwin'); if(claimBtn)claimBtn.classList.toggle('hide',!claimReady);
  const o = my === 'w' ? 'b' : 'w';
  const rt=rem(tForClock()); $('#ct').textContent = fmt(rem(o)); $('#cb').textContent = fmt(rem(my));
  const low=Math.min(rem('w'),rem('b')); if(low<=30000 && low>0) $('#st').textContent='⚠️ Az süre kaldı: '+fmt(low);
  if(!abortReady&&opponentOnline===false&&g.history().length===1&&g.turn()!==my&&!over){const wait=Math.max(0,60000-idleMs);$('#st').textContent='Rakip ilk hamlesini yapmadı · ELO etkilenmeden iptal '+fmt(wait)+' sonra açılır';}
  else if(!claimReady&&g.history().length>=2&&g.turn()!==my&&opponentOnline===false&&!over){const wait=Math.max(0,90000-idleMs);$('#st').textContent='Rakip çevrimdışı · galibiyet talebi '+fmt(wait)+' sonra açılır';}
  else if(claimReady) $('#st').textContent='Rakip çevrimdışı görünüyor. Galibiyet talep edebilirsin.';

  if (!over && !ending && started) {
    const t = g.turn();
    if (rem(t) <= 0) { ending = true; endWhy = t === my ? 'Süren bitti' : 'Rakibin süresi bitti'; endGame(t === 'w' ? 'b' : 'w', 'timeout'); }
  }
}
function sync(r) { ms = {w: r.white_ms, b: r.black_ms}; recv = Date.now(); }
async function endGame(outcome, reason='terminal') {
  try {
    const {data,error}=await sb.functions.invoke('chess-verify',{body:{action:'finish',gid,outcome,reason}});
    if (error || !data?.ok) { ending=false; msg=data?.error || 'Maç sonucu sunucuda doğrulanamadı.'; draw(); }
  } catch(e) { ending=false; msg='Maç sonucu gönderilemedi.'; draw(); }
}

// ===== Bot =====
// Kalibrasyon noktaları [bot puanı, Skill Level, maks. derinlik, hamle süresi ms] (lichess seviyelerine benzer, aralarda doğrusal geçiş)
const CAL = [[800, 0, 1, 50], [1100, 3, 1, 100], [1500, 6, 2, 150], [1800, 10, 4, 250], [2100, 14, 7, 400], [2400, 17, 11, 700], [2700, 19, 16, 1200], [3000, 20, 24, 2000], [3200, 20, 0, 3000]];
function cfg(r) {
  const c = cfg0(r); c.r = r; return c;
}
function cfg0(r) {
  if (r <= CAL[0][0]) return {skill: 0, depth: 1, mt: 50, blunder: .6 * (CAL[0][0] - r) / 550};
  for (let i = 1; i < CAL.length; i++) {
    if (r <= CAL[i][0]) {
      const a = CAL[i - 1], b = CAL[i], f = (r - a[0]) / (b[0] - a[0]), L = (x, y) => x + (y - x) * f;
      return {skill: Math.round(L(a[1], b[1])), depth: b[2] === 0 ? 0 : Math.max(1, Math.round(L(a[2], b[2]))), mt: Math.round(L(a[3], b[3])), blunder: 0};
    }
  }
  const z = CAL[CAL.length - 1]; return {skill: z[1], depth: 0, mt: z[3], blunder: 0};
}
let sfElo = false; // motor UCI_Elo destekliyorsa gerçek Elo sınırlaması kullanılır
async function engine() {
  if (sf !== null) { if (sf === false) noEngine = true; return sf; }
  try {
    // Stockfish 19 WASM worker doğrudan URL'den açılır; JS ve WASM aynı klasörde olmalı.
    sf = new Worker(SFS[0]);
    await new Promise((ok, fail) => {
      let settled = false;
      const finish = (err) => { if (settled) return; settled = true; clearTimeout(to); err ? fail(err) : ok(); };
      const to = setTimeout(() => finish(new Error('Stockfish 19 başlatma zaman aşımı')), 40000);
      const h = e => {
        const l = String(e.data);
        if (/option name UCI_Elo/.test(l)) sfElo = true;
        if (l.startsWith('uciok')) { sf.removeEventListener('message', h); finish(); }
      };
      sf.addEventListener('message', h);
      sf.onerror = () => finish(new Error('Stockfish 19 worker yüklenemedi'));
      sf.postMessage('uci');
    });
    sf.postMessage('isready');
    return sf;
  } catch (e) {
    try { sf?.terminate(); } catch {}
    sf = false; noEngine = true;
    window.__sfErr = String((e && e.message) || e).slice(0, 60);
    console.error('Stockfish 19 yüklenemedi:', e);
    if ((window.__sfFails = (window.__sfFails || 0) + 1) < 4) setTimeout(() => { if (sf === false) { sf = null; noEngine = false; } }, 3000); // yeniden dene
    return sf;
  }
}
function sfBest(fen, c) {
  return new Promise(res => {
    const h = e => { const l = String(e.data); if (l.startsWith('bestmove')) { sf.removeEventListener('message', h); res(l.split(' ')[1]); } };
    sf.addEventListener('message', h);
    if (sfElo && c.r >= 1320 && c.r < 3100) { sf.postMessage('setoption name UCI_LimitStrength value true'); sf.postMessage('setoption name UCI_Elo value ' + Math.min(3190, c.r)); }
    else { if (sfElo) sf.postMessage('setoption name UCI_LimitStrength value false'); sf.postMessage('setoption name Skill Level value ' + c.skill); }
    sf.postMessage('position fen ' + fen); sf.postMessage('go ' + (c.depth ? 'depth ' + c.depth + ' ' : '') + 'movetime ' + Math.round(c.mt));
  });
}
// Yedek motor: Stockfish açılamazsa (eski telefon, yavaş bağlantı vb.) basit bir alfa-beta araması oynar. Rastgeleden çok güçlüdür ama Stockfish değildir.
const MV = {p: 100, n: 320, b: 330, r: 500, q: 900, k: 0};
function miniEval(ch) {
  let s = 0, r = 0;
  for (const row of ch.board()) {
    let c = 0;
    for (const p of row) {
      if (p) { let v = MV[p.type]; if (p.type === 'p' || p.type === 'n' || p.type === 'b') v += (3.5 - Math.abs(c - 3.5)) * 4 + (3.5 - Math.abs(r - 3.5)) * 4; s += p.color === 'w' ? v : -v; }
      c++;
    }
    r++;
  }
  return ch.turn() === 'w' ? s : -s;
}
function miniOrder(ms) { return ms.sort((x, y) => ((y.captured ? MV[y.captured] * 10 - MV[y.piece] : 0) + (y.promotion ? 800 : 0)) - ((x.captured ? MV[x.captured] * 10 - MV[x.piece] : 0) + (x.promotion ? 800 : 0))); }
function miniSearch(ch, d, al, be, ply, st) {
  if (st.stop || Date.now() > st.end) { st.stop = true; return 0; }
  const ms = ch.moves({verbose: true});
  if (!ms.length) return ch.inCheck() ? -100000 + ply : 0;
  if (d <= 0) return miniEval(ch);
  miniOrder(ms);
  let best = -1e9;
  for (const m of ms) {
    ch.move({from: m.from, to: m.to, promotion: m.promotion});
    const v = -miniSearch(ch, d - 1, -be, -al, ply + 1, st);
    ch.undo();
    if (st.stop) return 0;
    if (v > best) best = v; if (v > al) al = v; if (al >= be) break;
  }
  return best;
}
function miniBest(game, c, legal) {
  const ch = new Chess(game.fen()), maxD = c.r < 1000 ? 1 : c.r < 1700 ? 2 : 3, noise = Math.max(0, (1900 - c.r) / 5), st = {stop: false, end: Date.now() + 1500};
  let best = legal[0], bestV = -1e9;
  for (let d = 1; d <= maxD; d++) {
    const ms = miniOrder(ch.moves({verbose: true})); let dBest = null, dV = -1e9, al = -1e9;
    for (const m of ms) {
      ch.move({from: m.from, to: m.to, promotion: m.promotion});
      let v = -miniSearch(ch, d - 1, -1e9, -al, 1, st);
      ch.undo();
      if (st.stop) break;
      v += Math.random() * noise;
      if (v > dV) { dV = v; dBest = m; } if (v > al) al = v;
    }
    if (st.stop) break;
    if (dBest) { best = dBest; bestV = dV; }
    if (bestV > 90000) break;
  }
  return legal.find(m => m.from === best.from && m.to === best.to && (m.promotion || '') === (best.promotion || '')) || legal[0];
}
async function botMove() {
  const c = cfg(botR), fen = g.fen(), t0 = Date.now(), legal = g.moves({verbose: true});
  let mv = null;
  if (Math.random() >= c.blunder && await engine()) { const u = await sfBest(fen, c); mv = legal.find(m => m.from + m.to + (m.promotion || '') === u); }
  if (!mv) { try { mv = miniBest(g, c, legal); } catch (e) { console.error('yedek motor hatası', e); } }
  if (!mv) mv = legal[Math.floor(Math.random() * legal.length)];
  // Daha görünür düşünme süresi (zayıf botlarda da net görülsün)
  const think = 700 + Math.min(900, botR / 4);
  await new Promise(r => setTimeout(r, Math.max(0, think - (Date.now() - t0))));
  if (over || !mv || mode !== 'bot' || g.fen() !== fen) return;
  const from = mv.from, to = mv.to;
  const res = g.move({from, to, promotion: mv.promotion}), chk = g.inCheck();
  last = [from, to]; if (g.isGameOver()) over = true;
  if(!over) savePracticeSnapshot(); else { try{localStorage.removeItem(practiceKey(mode)); localStorage.removeItem(PRACTICE_SAVE)}catch{} savePracticeGame(); }
  animateMove(from, to, () => { draw(); playMove(!!res.captured, chk); if (evalEnabled && !over) scheduleEval(); });
}

// ===== Hamle listesi / PGN =====
function plyNums(v) {
  const nums = new Array(v.length); let nn = +g.fen().split(' ')[5], t = g.turn();
  for (let i = v.length - 1; i >= 0; i--) { if (t === 'w') nn--; t = t === 'w' ? 'b' : 'w'; nums[i] = nn; }
  return nums;
}
function mlDraw() {
  const e = $('#ml'); if (!e || !g) return;
  const v = g.history({verbose: true}), nums = plyNums(v);
  e.innerHTML = v.map((m, i) => {
    const n = m.color === 'w' ? nums[i] + '. ' : i === 0 ? nums[i] + '… ' : '';
    const t = (n ? `<span style="opacity:.6">${n}</span>` : '') + m.san;
    return i === v.length - 1 ? `<b style="color:var(--fg)">${t}</b>` : t;
  }).join(' ') || '&nbsp;';
  e.scrollLeft = e.scrollWidth;
}
function pgnText() {
  const today = new Date().toISOString().slice(0, 10).replace(/-/g, '.');
  let wn = 'Beyaz', bn = 'Siyah';
  if (mode === 'online' && row0) { wn = row0.white_name || wn; bn = row0.black_name || bn; }
  else if (mode === 'bot') { const me = prof ? prof.username : 'Sen', cpu = 'Bilgisayar ' + botR; wn = my === 'w' ? me : cpu; bn = my === 'w' ? cpu : me; }
  const r = g.isCheckmate() ? (g.turn() === 'w' ? '0-1' : '1-0') : g.isDraw() ? '1/2-1/2' : over ? (endRes === 'w' ? '1-0' : endRes === 'b' ? '0-1' : endRes === 'd' ? '1/2-1/2' : '*') : '*';
  g.header('Event', 'E Chess', 'Site', 'satranc.app', 'Date', today, 'White', wn, 'Black', bn, 'Result', r);
  return g.pgn();
}
async function pgnExport() {
  if (!g || !g.history().length) return ask('Henüz hamle yok.', 'Tamam', true);
  const t = pgnText();
  try { await navigator.clipboard.writeText(t); await ask('PGN panoya kopyalandı. lichess.org/paste adresine yapıştırıp inceleyebilirsin.', 'Tamam', true); return; } catch {}
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([t], {type: 'text/plain'})); a.download = 'echess.pgn';
  document.body.appendChild(a); a.click(); a.remove();
}

// ===== Sürükle-bırak =====
function markSel() {
  document.querySelectorAll('#bd .sq.s, #bd .sq.t').forEach(x => x.classList.remove('s', 't', 'c'));
  if (!sel) return;
  const o = sqEl(sel); if (o) o.classList.add('s');
  for (const m of tg) { const el = sqEl(m.to); if (el) { el.classList.add('t'); if (g.get(m.to)) el.classList.add('c'); } }
}
function promoAsk(m) {
  pend = m;
  $('#pr').innerHTML = ['q','r','b','n'].map(x => `<button data-a="promo:${x}"><img src="${PC}${mine()}${x.toUpperCase()}.svg" alt=""></button>`).join('');
  $('#pr').classList.remove('hide');
}
$('#bd').addEventListener('pointerdown', e => {
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  const q = e.target.closest('.sq');
  if (!q || !g || !mode || over || hintBusy || pend || vi != null || g.turn() !== mine()) return;
  const p = g.get(q.dataset.s);
  if (!p || p.color !== mine()) return;
  drag = {s: q.dataset.s, x: e.clientX, y: e.clientY, id: e.pointerId, on: false, ghost: null, touch: e.pointerType !== 'mouse'};
});
window.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  if (!drag.on) {
    if (Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 8) return;
    drag.on = true; sel = drag.s; tg = g.moves({square: drag.s, verbose: true}); markSel();
    const el = sqEl(drag.s), img = el && el.querySelector('img.p');
    if (img) {
      const w = img.getBoundingClientRect().width * 1.25, gh = img.cloneNode();
      gh.className = 'ghost'; gh.style.width = gh.style.height = w + 'px'; drag.ghost = gh; document.body.appendChild(gh); img.style.opacity = '.3';
    }
  }
  if (drag.ghost) { drag.ghost.style.left = e.clientX + 'px'; drag.ghost.style.top = (e.clientY - (drag.touch ? 28 : 0)) + 'px'; }
});
function dragStop(e, cancel) {
  if (!drag || e.pointerId !== drag.id) return;
  const d = drag; drag = null;
  if (!d.on) return;
  dragEnd = Date.now();
  if (d.ghost) d.ghost.remove();
  let m = null;
  if (!cancel) {
    const el = document.elementFromPoint(e.clientX, e.clientY), q = el && el.closest ? el.closest('#bd .sq') : null;
    if (q && q.dataset.s === d.s) { draw(); return; }   // aynı kareye bırakıldı: seçili kalsın
    if (q) m = tg.find(x => x.to === q.dataset.s) || null;
  }
  if (m && !over && g.turn() === mine()) { if (m.promotion) { draw(); promoAsk(m); } else doMove(m); return; }
  sel = null; tg = []; draw();
}
window.addEventListener('pointerup', e => dragStop(e, false));
window.addEventListener('pointercancel', e => dragStop(e, true));

// ===== İpucu ve analiz (Stockfish) =====
function sfEval(fen, mt) {
  return new Promise(res => {
    let sc = null;
    const h = e => {
      const l = String(e.data);
      if (l.startsWith('info') && !/lowerbound|upperbound/.test(l)) {
        const m = l.match(/score (cp|mate) (-?\d+)/);
        if (m) sc = m[1] === 'cp' ? +m[2] : (+m[2] > 0 ? 100000 - +m[2] : -100000 - +m[2]);
      } else if (l.startsWith('bestmove')) { sf.removeEventListener('message', h); const b = l.split(' ')[1]; res({best: b && b !== '(none)' ? b : null, cp: sc}); }
    };
    sf.addEventListener('message', h);
    if (sfElo) sf.postMessage('setoption name UCI_LimitStrength value false');
    sf.postMessage('setoption name Skill Level value 20');
    sf.postMessage('position fen ' + fen); sf.postMessage('go movetime ' + mt);
  });
}
async function hintGo() {
  if (!g || !mode || mode === 'online' || over || hintBusy || g.turn() !== mine()) return;
  hintBusy = true; msg = 'İpucu hesaplanıyor…'; draw();
  const fen = g.fen(); let u = null, ok = false;
  if (await engine()) { ok = true; u = (await sfEval(fen, 700)).best; }
  hintBusy = false; msg = ok ? '' : 'Motor yüklenemedi, ipucu verilemiyor.';
  if (u && g.fen() === fen) hint = {fen, from: u.slice(0, 2), to: u.slice(2, 4)};
  draw();
}
async function analyze() {
  if (!g || !g.history().length) return ask('Analiz için önce hamle yapılmalı.', 'Tamam', true);
  // Ayrı inceleme ekranı sabit derinlikli Stockfish analizi, ilerleme/iptal,
  // hamle sınıflandırması, avantaj grafiği ve analiz önbelleğini yönetir.
  const reviewUrl = new URL('/review.html', location.origin);
  reviewUrl.searchParams.set('pgn', pgnText());
  location.href = reviewUrl.href;
}

// ===== Online: beraberlik teklifi ve rövanş =====
function drBtn() { const b = $('#dr'); if (!b) return; b.disabled = !!over || drawOff === my; b.textContent = drawOff === my ? 'Teklif edildi' : 'Beraberlik'; }
async function drawAsk() {
  const tok = ++drawTok; dlgDraw = true;
  const ok = await ask('Rakip beraberlik teklif ediyor. Kabul ediyor musun?', 'Kabul et', false, 'Reddet');
  dlgDraw = false;
  if (tok !== drawTok || over || !gid) return;
  try { await sb.rpc('respond_draw', {p_gid: gid, p_accept: ok}); } catch {}
}
function drawState(r) {
  const prev = drawOff; drawOff = r.status === 'playing' ? (r.draw_offer || null) : null;
  if (dlgDraw && (!drawOff || drawOff === my)) { drawTok++; askCancel(); }
  if (drawOff && drawOff !== my && !dlgDraw && !over) drawAsk();
  if (prev === my && !drawOff && r.status === 'playing' && r.draw_declined_fen === r.fen) {
    msg = 'Rakip beraberliği reddetti.';
    setTimeout(() => { if (msg.startsWith('Rakip beraberliği')) { msg = ''; draw(); } }, 3000);
  }
  drBtn();
}
async function joinNext(id) {
  if (joining) return; joining = true;
  try {
    const {data} = await sb.from('chess_games').select('*').eq('id', id).maybeSingle();
    if (!data || data.status !== 'playing') return;
    if (ch) { await sb.removeChannel(ch); ch = null; }
    clearInterval(tick); clearTimeout(finTimer);
    gid = data.id; started = true; sub(gid); start('online', data);
  } finally { joining = false; }
}

// ===== Online =====
async function leave() {
  anTok++; if (mode === 'online' && rmWait && gid) sb.rpc('cancel_rematch', {p_gid: gid}).then(() => {}, () => {});
  clearInterval(wt); clearTimeout(waitTimeout); waitTimeout=null; clearInterval(tick); clearInterval(presenceTimer); presenceTimer=null; if (chal) cancelChal();
  if (ch) { await sb.removeChannel(ch); ch = null; }
  if (gid && !started) await sb.from('chess_games').delete().eq('id', gid).eq('status', 'waiting');
  clearTimeout(finTimer); localStorage.removeItem(SAVE); $('#ov').classList.add('hide');
  gid = null; started = false; mode = null; over = true; pushing = 0;
}
function presenceSync() {
  const el=$('#presence'); if(!el||mode!=='online'||!row0)return;
  const opponentId=my==='w'?row0.black_id:row0.white_id;
  const state=ch?.presenceState?.()||{};
  const online=Object.values(state).flat().some(meta=>meta&&meta.user_id===opponentId); opponentOnline=online;
  el.textContent=online?'● Rakip çevrimiçi':'○ Rakip çevrimdışı / bağlantı bekleniyor';
  el.style.color=online?'var(--g)':'var(--mut)';
}
async function heartbeatPresence(){if(mode!=='online'||!gid||!user||!started||over)return;try{await sb.from('game_presence').upsert({game_id:gid,user_id:user.id,seen_at:new Date().toISOString()},{onConflict:'game_id,user_id'});}catch{}}
function sub(id) {
  clearInterval(presenceTimer);
  const channel=sb.channel('g'+id,{config:{presence:{key:user?.id||'guest'}}})
    .on('postgres_changes', {event: 'UPDATE', schema: 'public', table: 'chess_games', filter: 'id=eq.' + id}, p => onRow(p.new))
    .on('presence',{event:'sync'},presenceSync)
    .on('presence',{event:'join'},presenceSync)
    .on('presence',{event:'leave'},presenceSync);
  ch=channel;
  channel.subscribe(async status=>{if(status==='SUBSCRIBED'){try{await channel.track({user_id:user.id,seen_at:new Date().toISOString()});}catch{}presenceSync();heartbeatPresence();clearInterval(presenceTimer);presenceTimer=setInterval(heartbeatPresence,15000);}});
}
async function findOnline() {
  if (!ONLINE_OK || !navigator.onLine) return ask('Gerçek rakiple oynamak için internet gerekli. Bilgisayara karşı oynayabilirsin.', 'Tamam', true);
  if (!user || !prof) { $('#err').textContent = 'Online oynamak için giriş yap.'; return show('auth'); }
  show('wait'); $('#wh').textContent = 'Rakip aranıyor…'; $('#wtxt').textContent = tc + ' dk · en yakın puanlı rakip aranıyor'; started = false;
  const mine = prof.elo, since = new Date(Date.now() - 90000).toISOString();
  const {data, error: searchError} = await sb.from('chess_games').select('*').eq('status', 'waiting').is('black_id', null).eq('tc', tc).neq('white_id', user.id).gt('updated_at', since).order('updated_at', {ascending:true}).limit(20);
  if (searchError) { $('#wtxt').textContent = 'Rakip aranırken bağlantı hatası oluştu. Tekrar deneyebilirsin.'; return; }
  for (const w of (data || []).sort((a, b) => Math.abs(a.white_rating - mine) - Math.abs(b.white_rating - mine))) {
    const {data: u} = await sb.from('chess_games').update({black_id: user.id, black_name: prof.username, black_rating: mine, status: 'playing'}).eq('id', w.id).eq('status', 'waiting').is('black_id', null).select();
    if (u && u.length) { gid = u[0].id; started = true; sub(gid); return start('online', u[0]); }
  }
  const {data: n, error} = await sb.from('chess_games').insert({tc, white_id: user.id, white_name: prof.username, white_rating: mine, white_ms: tc * 60000, black_ms: tc * 60000}).select().single();
  if (error) { $('#wtxt').textContent = 'Bağlantı hatası.'; return; }
  gid = n.id; sub(gid);
  wt = setInterval(() => sb.from('chess_games').update({status: 'waiting', updated_at: new Date().toISOString()}).eq('id', gid).eq('status', 'waiting').is('black_id', null), 30000);
  const waitingId=gid;
  waitTimeout=setTimeout(async()=>{
    if(gid!==waitingId || started || mode==='online') return;
    clearInterval(wt); wt=null;
    await sb.from('chess_games').delete().eq('id',waitingId).eq('status','waiting');
    gid=null; if(ch){await sb.removeChannel(ch);ch=null;}
    const playBot=await ask('60 saniye içinde rakip bulunamadı. Bilgisayara karşı oynamak ister misin?','Botla oyna');
    if(playBot){await leave(); start('bot',null,Math.max(800,Math.min(2400,prof?.elo||1200)));} else {await leave();home();}
  },60000);
}
function applyRemote(r) {
  capNow = false;
  if (r.fen === g.fen()) return;
  if (r.last) {
    const [from, to] = r.last.split(',');
    for (const p of [undefined, 'q', 'r', 'b', 'n']) {
      let res; try { res = g.move({from, to, promotion: p}); } catch { continue; }
      if (g.fen() === r.fen) { last = [from, to]; capNow = !!res.captured; return; }
      g.undo();
    }
  }
  if (Array.isArray(r.move_history)) {
    try { g = new Chess(); for (const san of r.move_history) g.move(san); }
    catch { g = new Chess(r.fen); }
  } else g = new Chess(r.fen);
  last = r.last ? r.last.split(',') : null; // sunucu doğrulamalı hamle geçmişi ayrıca saklanır
}
function onRow(r) {
  if(row0)row0=r; presenceSync();
  if (!started) { if (r.status === 'playing') { started = true; clearInterval(wt); start('online', r); } return; }
  sync(r);
  drawState(r);
  let moved = false;
  if (!pushing) { const before = g.fen(); applyRemote(r); moved = g.fen() !== before; if (moved) { sel = null; tg = []; } }
  if (r.status === 'finished') {
    clearTimeout(finTimer);
    over = true; endRes = r.result; msg = r.result === 'd' ? 'Berabere.' : r.result === my ? 'Kazandın.' : 'Kaybettin.';
    if (r.result === 'd' && !g.isGameOver()) endWhy = 'Beraberlik anlaşması';
    rmWait = r.rematch_by === my; rmFrom = r.rematch_by && r.rematch_by !== my ? r.rematch_by : null; if (rmFrom) ovDismissed = false;
    if (r.next_game_id) joinNext(r.next_game_id);
    clearInterval(tick); clearInterval(presenceTimer); localStorage.removeItem(SAVE);
    if (!eloAsked) { eloAsked = true; getElo(true); }
  } else if (g.isGameOver() && !pushing) {
    // Hamleyi yapan taraf sonucu bildirmezse (bağlantı koptuysa) 3 sn sonra biz bildirelim
    const id = gid; clearTimeout(finTimer);
    finTimer = setTimeout(() => { if (gid === id && mode === 'online' && !over) endGame(g.isCheckmate() ? (g.turn() === 'w' ? 'b' : 'w') : 'd', 'terminal'); }, 3000);
  }
  if (moved && last && last.length === 2) animateMove(last[0], last[1], () => { draw(); playMove(capNow, g.inCheck()); }); else draw();
  if (moved && premove && g.turn()===my && !over) { const q=premove; premove=null; const legal=g.moves({verbose:true}).find(x=>x.from===q.from&&x.to===q.to); if(legal) doMove({...legal,promotion:q.promotion||legal.promotion}); else draw(); }
}
async function refresh() {
  if (!gid || mode !== 'online') return;
  const {data} = await sb.from('chess_games').select('*').eq('id', gid).maybeSingle();
  if (data) onRow(data);
}
async function push() {
  pushing++;
  try {
    const moves = g.history();
    const {data,error} = await sb.functions.invoke('chess-verify', {body:{action:'move', gid, moves}});
    if (error || !data?.ok) {
      msg = data?.error || 'Sunucu hamleyi doğrulayamadı. Bağlantıyı kontrol et.';
      draw(); await refresh(); return;
    }
    sync(data.game);
    if (data.game && data.game.status === 'finished') onRow(data.game);   // sunucu mat/beraberliği hamlede kendisi bitirir
  } catch (e) {
    msg = 'Hamle sunucuya gönderilemedi.'; draw(); await refresh();
  } finally { pushing--; }
}
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') { if (mode === 'bot' || mode === 'local') savePracticeSnapshot(); return; }
  if (mode === 'online' && started) refresh();
  else if (gid && !started) sb.from('chess_games').select('*').eq('id', gid).maybeSingle().then(({data}) => { if (data) onRow(data); });
});
window.addEventListener('online', () => { if (mode === 'online' && started) refresh(); });
window.addEventListener('offline', () => { if (mode === 'bot' || mode === 'local') savePracticeSnapshot(); if (mode === 'online' && started) { msg = 'İnternet bağlantısı kesildi. Bağlantı gelince oyun otomatik eşitlenecek.'; draw(); } });
window.addEventListener('pagehide', () => { if (mode === 'bot' || mode === 'local') savePracticeSnapshot(); });

if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});

// ← → tuşlarıyla hamleleri gez (maç bitse de çalışır)
document.addEventListener('keydown', e => {
  if (!g || !mode || /INPUT|TEXTAREA/.test((e.target.tagName || ''))) return;
  const a = e.key === 'ArrowLeft' ? 'prev' : e.key === 'ArrowRight' ? 'next' : e.key === 'Home' ? 'first' : e.key === 'End' ? 'live' : null;
  if (a) { e.preventDefault(); document.querySelector(`.nv [data-a="${a}"]`)?.click(); }
});
